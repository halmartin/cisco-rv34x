unsigned int pmul_size = 160;
unsigned int pmul_k_size = 4;
unsigned int pmul_curve = 0;
unsigned int pmul_m[] = {0x00000003};


unsigned int pmul_rx[] ={
0x7B76FF54,
0x1EF363F2,
0xDF13DE16,
0x50BD48DA,
0xA958BC59
};
unsigned int pmul_ry [] = {
0xC915CA79,
0x0D8C8877,
0xB55BE007,
0x9D12854F,
0xFE9F6F5A
};
