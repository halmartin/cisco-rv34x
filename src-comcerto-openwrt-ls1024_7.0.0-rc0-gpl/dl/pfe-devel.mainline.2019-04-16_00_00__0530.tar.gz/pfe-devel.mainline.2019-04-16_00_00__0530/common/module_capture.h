
/*
 *  Copyright (c) 2011, 2014 Freescale Semiconductor, Inc.
 *
 *  THIS FILE IS CONFIDENTIAL.
 *
 *  AUTHORIZED USE IS GOVERNED BY CONFIDENTIALITY AND LICENSE AGREEMENTS WITH FREESCALE SEMICONDUCTOR, INC.
 *
 *  UNAUTHORIZED COPIES AND USE ARE STRICTLY PROHIBITED AND MAY RESULT IN CRIMINAL AND/OR CIVIL PROSECUTION.
 */

#ifndef _MODULE_CAPTURE_H_
#define _MODULE_CAPTURE_H_

#include "types.h"
#include "modules.h"
#include "channels.h"
#include "system.h"
#include "module_Rx.h"

#ifdef CFG_PCAP

#if !defined(COMCERTO_2000)
#define SMI_CAP_EXPTQ_ADDR 	0x0A0004A0
#define MAX_FILL_CAP_DESC 		RX_BUDGET// This is dependent on RX_BUDGET parameter.
#endif

#define MAX_CAP_QUERY_IFACES 	2


#define CAP_STATUS_ENABLED 	1
#define CAP_STATUS_DISABLED	0

#define CAP_DEFAULT_SLICE		96
#define CAP_MAX_FLF_INSTRUCTIONS 	30


#define CAP_IFSTATUS_ENABLED 	1
#define CAP_IFSTATUS_DISABLED	0

#define PCAP_MAX_BPF_INST_SUPPORTED	128

#if !defined (COMCERTO_2000)

typedef struct tCAPEXPT_context {
	U32 cap_Q_PTR;		// capture descriptors base address
	U16 cap_enable;
	U16 rsvd;
	U32 cap_irqm;		// capture interrrupt
	U32 cap_wrt_index;

} CAPEXPT_context, *PCAPEXPT_context;


//STATUS BITS in cap_status

#define CAP_OWN		(1<<29)
#define CAP_WRAP	(1<<30)

#define CAP_LENGTH_MASK 0x1FFF
#define CAP_SLICE_BIT	  16

#define CAP_IFINDEX  29
#define CAP_IFINDEX_MASK 3



//typedef struct __attribute__((aligned(16))) tCapDesc {

typedef struct  tCapDesc {
	U32 cap_data;
	U32 cap_len; 
	U32 cap_status;
	U32 cap_tmpstmp;
} CAPDesc , *pCAPDesc;

typedef struct  tCapDesc_short {
	U32 cap_len; 
	U32 cap_tmpstmp;
} CAPDesc_short , *pCAPDesc_short;

#endif

#define ACTION_IF_STATUS	0x1
#define ACTION_SLICE	 	0x2

typedef struct tcmdCapStat
{
	U16 		action;
	U8		ifindex;
	U8		status;
}CAPStatCmd, *PCAPStatCmd;

typedef struct tcmdCapSlice
{
	U16 		action;
	U8		ifindex;
	U8		rsvd;
	U16 		slice;
}CAPSliceCmd, *PCAPSliceCmd;

typedef struct tcmdCapQuery{
	U16     slice;
	U16     status;
} __attribute__((packed)) CAPQueryCmd;

typedef  struct tCapbpf_insn/* bpf instruction */{
	U16 code;   /* Actual filter code */
	U8   jt;     /* Jump true */
	U8   jf;     /* Jump false */
	U32  k;      /* Generic multiuse field */
}Capbpf_insn;

#if defined(COMCERTO_2000_CLASS)
typedef struct tCapflf/* First level filter */{
	U32 flen; /* filter length */
	Capbpf_insn filter[PCAP_MAX_BPF_INST_SUPPORTED];
}CAPflf;
#else
typedef struct tCapflf/* First level filter */{
	U16 flen; /* filter length */
	Capbpf_insn *filter;
}CAPflf;
#endif

#if defined (COMCERTO_2000_CONTROL)
typedef struct tCapflf_hw/* First level filter */{
	U32 flen; /* filter length */
	Capbpf_insn filter[PCAP_MAX_BPF_INST_SUPPORTED];
}CAPflf_hw;
#endif


typedef struct tCapCfgflf/* First level filter */{
	U16 flen; /* filter length */
	U8  ifindex;
	U8  mfg; /* set to inform fpp of fragment no, last fragment has the field set to 0 */
	Capbpf_insn filter[CAP_MAX_FLF_INSTRUCTIONS];
}CAPcfgflf;

typedef struct tCAPCtrl
{
	U16 cap_status;
	U16 cap_slice;
#if !defined (COMCERTO_2000)
	CAPflf  cap_flf;
#endif
}CAPCtrl;

#if defined (COMCERTO_2000)
extern u8 g_pcap_enable;
extern u32 cap_pkt_cnt;
extern CAPCtrl gCapCtrl[GEM_PORTS];
extern CAPflf gCapFilter[GEM_PORTS];
#if !defined(COMCERTO_2000_CONTROL)
void pcap_tstamp_upd_lmem ();
u32 pcap_get_tstamp_in_us();
void M_PKTCAP_process_packet(PMetadata mtd);
void M_pktcap_process(PMetadata mtd, U8 ifindex);
void M_pktcap_process_ddrpkt(u32 port, void *ddr_addr, u32 len);
void M_pktcap_process_mcast(PMetadata mtd, void *tx_hdr_start);
#if defined(COMCERTO_2000_CLASS)
int M_pktcap_filter_frame(u8* pkt,u16 pkt_len,Capbpf_insn * filter, U32 flen) __attribute__((section ("slow_pmem")));
void pcap_init(void);
extern int (*pktcap_flf_fnptr)(u8* pkt, u16 pkt_len,  Capbpf_insn * filter, U32 flen);
#endif
static inline int M_pktcap_chk_enable(U8 ifindex)
{
	if (g_pcap_enable && (gCapCtrl[ifindex].cap_status & CAP_STATUS_ENABLED))
		return 1;

	return 0;
}
#define CAP_LMEM_WRAPS_ADDR		0xC0308100
#define CAP_LMEM_CYCLES_ADDR		0xC0308104

#if defined (COMCERTO_2000_CLASS)
#define CAP_DMEM_BUFFER			CLASS_GP_DMEM_BUF
#define CAP_DMEM_BUFFER_SIZE		CLASS_GP_DMEM_BUF_SIZE
#endif
#if defined (COMCERTO_2000_UTIL)
#include "util_dmem_storage.h"
#define CAP_DMEM_BUFFER                MEMCPY_TMP_BUF
#define CAP_DMEM_BUFFER_SIZE   MEMCPY_TMP_BUF_SIZE
#endif

#endif
#else
extern CAPEXPT_context gCapExpt;
extern CAPCtrl gCapCtrl[GEM_PORTS];
extern U32 gCapData[MAX_FILL_CAP_DESC];
extern CAPDesc_short gCapCtlShort[MAX_FILL_CAP_DESC];

void M_PKTCAP_process_packet(PMetadata mtd);
void M_pktcap_entry(void) __attribute__((section ("fast_path")));
BOOL M_pktcap_init(PModuleDesc pModule);
int M_pktcap_process(PMetadata mtd, U8 ifindex)  __attribute__((section ("fast_path")));

static inline int M_pktcap_chk_enable(PMetadata mtd , U8 ifindex)
{
	if (gCapExpt.cap_enable && (gCapCtrl[ifindex].cap_status & CAP_STATUS_ENABLED))
		return 1;

	return 0;
}
#endif
int pktcap_init(void);
void pktcap_exit(void);

#endif /* CFG_PCAP */
#endif /* _MODULE_CAPTURE_H_ */

