/*
 *
 *  Copyright (C) 2007 Freescale Semiconductor, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#ifdef __KERNEL__
#include <linux/module.h>
#endif

#include "pfe_mod.h"

#ifdef CFG_FLOW_STATS

int register_del_conn_indication_cb(void (*del_conn_cb)(PCtStats,PCtStats))
{
	if (NULL == del_conn_cb)
		return -1;

	pfe->update_ct_stats_cb = del_conn_cb;
	return 0;
}
EXPORT_SYMBOL(register_del_conn_indication_cb);


int deregister_del_conn_indication_cb(void)
{
	pfe->update_ct_stats_cb = NULL;
	return 0;
}

EXPORT_SYMBOL(deregister_del_conn_indication_cb);
#endif /* CFG_FLOW_STATS */
