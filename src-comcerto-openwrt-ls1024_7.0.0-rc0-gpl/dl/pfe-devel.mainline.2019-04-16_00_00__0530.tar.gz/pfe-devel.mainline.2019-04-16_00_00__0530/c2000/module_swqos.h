/*
 *  Copyright (c) 2011, 2014 Freescale Semiconductor, Inc.
 *
 *  THIS FILE IS CONFIDENTIAL.
 *
 *  AUTHORIZED USE IS GOVERNED BY CONFIDENTIALITY AND LICENSE AGREEMENTS WITH FREESCALE SEMICONDUCTOR, INC.
 *
 *  UNAUTHORIZED COPIES AND USE ARE STRICTLY PROHIBITED AND MAY RESULT IN CRIMINAL AND/OR CIVIL PROSECUTION.
 */


#ifndef _MODULE_SWQOS_H_
#define _MODULE_SWQOS_H_

#include "types.h"
#include "math.h"
#include "bitlist.h"
#include "swqos_mtd.h"

#if 1
#define DPRINT(fmt, args...) printk(KERN_ERR "%s: " fmt, __func__, ##args)
#else
#define DPRINT(fmt, args...) do {} while(0)
#endif

#define ENTER() DPRINT("enter\n")
#define EXIT() DPRINT("exit\n")

#define	SWQOS_MAX_MTD	4096

static inline void ENABLE_HIF_NOCPY_RX_INTERRUPTS(void)
{
       writel(HIF_INT_EN | HIF_RXPKT_INT_EN, HIF_NOCPY_INT_ENABLE);
}

static inline void DISABLE_HIF_NOCPY_RX_INTERRUPTS(void)
{
       writel(0, HIF_NOCPY_INT_ENABLE);
}

void SWQOS_start_timer(void);
void SWQOS_stop_timer(void);

int swqos_init(void);
void swqos_exit(void);

extern volatile u32 swqos_timer_tickcount;
extern volatile u32 swqos_process_tickcount;

#define SWQOS_lock() spin_lock_bh(&hif_nocpy->lock)
#define SWQOS_unlock() spin_unlock_bh(&hif_nocpy->lock)

#define SWQOS_schedule() napi_schedule(&hif_nocpy->napi)

//======================================================================

#define SWQOS_NUM_SHAPERS		256
#define SWQOS_NUM_SCHEDULERS		16
#define SWQOS_NUM_QUEUES		128

#define SWQOS_CONGESTION_LEVEL	300

#define SW_QUEUE_MASK		(SWQOS_NUM_QUEUES - 1)

#define SWQOS_ALG_PQ	0
#define SWQOS_ALG_CBWFQ	1
#define SWQOS_ALG_DWRR	2
#define SWQOS_ALG_RR	3
#define SWQOS_ALG_LAST	SWQOS_ALG_RR

#define SWQOS_RX_MTU 	1518
//#define SWQOS_IFG_SIZE	20
#define SWQOS_IFG_SIZE	0		/* Default IFG is 0 for SW shapers */
#define SWQOS_FCS_SIZE	4

#define SWQOS_LENGTH(mtd) ((u32)(mtd)->length + SWQOS_FCS_SIZE)

//======================================================================

typedef struct tSWQOS_QDesc {
        PSWQOS_MTD head;		// output queue head pointer
        PSWQOS_MTD tail;		// output queue tail pointer
        u16 current_qdepth;		// number of packets on this output queue
        u16 max_qdepth;			// maximum number of packets allowed on this output queue
	u8 sched_num;			// number of scheduler assigned to this queue (if none, set to 0xFF)
	u8 init_flag;			// set to TRUE when first packet is enqueued
	u8 alg;				// scheduling algorithm for assigned scheduler
	u8 ready_flag;			// set to TRUE if queue is ready to transmit
	u16 weight;			// queue weight
	u16 unused2;
	BITLIST_DECLARE(shaperlist, SWQOS_NUM_SHAPERS);	// shapers assigned to this queue
        union {           		// each struct in this union is for a specific algorithm
            struct {      // CBWFQ
                u32 cbwfq_finish_time;	// "time" to transmit next packet
            };
            struct {      // DWRR
                int dwrr_credits;	// available credits remaining
            };
        };
} SWQOS_QDesc, *PSWQOS_QDesc;

typedef struct tSWQOS_ShaperDesc {
	BITLIST_DECLARE(qlist, SWQOS_NUM_QUEUES);	// list of queues assigned to this shaper
	BITLIST_DECLARE(active_queues, SWQOS_NUM_QUEUES);	// list of active queues assigned to this shaper
	u8 enable_flag;			// set to TRUE if shaper is enabled
	u8 ifg;				// extra IFG amount to add to packet length
	u8 unused[2];
	u32 tokens_per_clock_period;	// bits worth of tokens available on every 1 msec clock period
	int tokens_available;		// bits available to transmit
	int bucket_size;		// max bucket size in bytes
} SWQOS_ShaperDesc, *PSWQOS_ShaperDesc;

typedef struct tSWQOS_SchedDesc {
	BITLIST_DECLARE(qlist, SWQOS_NUM_QUEUES);	// list of queues assigned to this scheduler
	BITLIST_DECLARE(ready_queues, SWQOS_NUM_QUEUES);	// list of queues ready to transmit
	u8 alg;				// current scheduling algorithm
	u8 unused;
	union {				// each struct in this union is for a specific algorithm
            struct {	// RR
		u8 rr_current_queue;	// current active queue number
            };
            struct {	// DWRR
		u16 dwrr_mult_factor;	// multiplication factor to make minimum weight >= 1000
		u8 dwrr_current_queue;	// current active queue number
		u8 dwrr_next_flag;	// set to TRUE when current queue number must be updated
            };
	};
} SWQOS_SchedDesc, *PSWQOS_SchedDesc;

typedef struct tSWQOS_context {
	u32 num_packets_queued;		// current number of queued packets (on all queues)
	BITLIST_DECLARE(active_queues, SWQOS_NUM_QUEUES);		// list of non-empty queues
	BITLIST_DECLARE(ready_schedulers, SWQOS_NUM_SCHEDULERS);	// list of ready schedulers
	BITLIST_DECLARE(enabled_shapers, SWQOS_NUM_SHAPERS);	// list of enabled shapers
	SWQOS_ShaperDesc shaper[SWQOS_NUM_SHAPERS];	// shaper descriptors
	SWQOS_SchedDesc sched[SWQOS_NUM_SCHEDULERS];	// scheduler descriptors
	SWQOS_QDesc q[SWQOS_NUM_QUEUES];		// queue descriptors
	u32 packets_processed[SWQOS_NUM_QUEUES];	// packets processed stats
	u32 total_packets_dropped;			// total packets dropped stat
	u32 packets_dropped[SWQOS_NUM_QUEUES];		// packets dropped per queue stats
} __attribute__((aligned(32))) SWQOS_context, *PSWQOS_context;

//======================================================================

// commands

typedef struct _swqos_reset_cmd {
	unsigned short	reserved1;
	unsigned short	reserved2;
} swqos_reset_cmd_t;              

typedef struct _swqos_config_shaper_cmd {
	unsigned short	shaper;
	unsigned char	reset_flag;
	unsigned char	enable_flag;
	unsigned char	ifg;
	unsigned char	reserved[3];
        unsigned int	rate;
        unsigned int	bucket_size;
	unsigned int	queue_array[SWQOS_NUM_QUEUES / 32];
} swqos_config_shaper_cmd_t, *pswqos_config_shaper_cmd_t;

typedef struct _swqos_config_scheduler_cmd {
	unsigned short	scheduler;
	unsigned char	reset_flag;
	unsigned char	algo;
	unsigned int	queue_array[SWQOS_NUM_QUEUES / 32];
} swqos_config_scheduler_cmd_t, *pswqos_config_scheduler_cmd_t;

typedef struct _swqos_config_queue_cmd {
	unsigned short	queue;
	unsigned short	qweight;
	unsigned short	max_qdepth;
	unsigned short	reserved;
} swqos_config_queue_cmd_t, *pswqos_config_queue_cmd_t;

typedef struct _swqos_query_shaper_cmd {
	unsigned short	shaper;
	unsigned short	reserved;
} swqos_query_shaper_cmd_t, *pswqos_query_shaper_cmd_t;

typedef struct _swqos_query_scheduler_cmd {
	unsigned short	scheduler;
	unsigned short	reserved;
} swqos_query_scheduler_cmd_t, *pswqos_query_scheduler_cmd_t;

typedef struct _swqos_query_queue_cmd {
	unsigned short	queue;
	unsigned short	reset_flag;
} swqos_query_queue_cmd_t, *pswqos_query_queue_cmd_t;

typedef struct _swqos_query_shaper_rsp {
	unsigned short	retcode;
	unsigned short	shaper;
	unsigned char	enable_flag;
	unsigned char	ifg;
	unsigned char	reserved[2];
        unsigned int	rate;
        unsigned int	bucket_size;
	unsigned int	queue_array[SWQOS_NUM_QUEUES / 32];
} swqos_query_shaper_rsp_t, *pswqos_query_shaper_rsp_t;

typedef struct _swqos_query_scheduler_rsp {
	unsigned short	retcode;
	unsigned short	scheduler;
	unsigned char	algo;
	unsigned char	reserved[3];
	unsigned int	queue_array[SWQOS_NUM_QUEUES / 32];
} swqos_query_scheduler_rsp_t, *pswqos_query_scheduler_rsp_t;

typedef struct _swqos_query_queue_rsp {
	unsigned short	retcode;
	unsigned short	queue;
	unsigned short	qweight;
	unsigned short	max_qdepth;
	unsigned char	scheduler;
	unsigned char	reserved[3];
	unsigned int	packets_processed;
	unsigned int	packets_dropped;
	unsigned int	shaper_array[SWQOS_NUM_SHAPERS / 32];
} swqos_query_queue_rsp_t, *pswqos_query_queue_rsp_t;

extern SWQOS_context swcontext;
#define SWQOS_GET_CONTEXT() (&swcontext)

#endif /* _MODULE_SWQOS_H_ */
