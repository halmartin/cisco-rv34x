/*Auto-generated file. Do not edit !*/
#ifndef PFE_VERSION_H

#define PFE_VERSION_H

#define PFE_VERSION "tag_rv34x_mr1_v1.0.03.14"

#endif /* PFE_VERSION_H */
