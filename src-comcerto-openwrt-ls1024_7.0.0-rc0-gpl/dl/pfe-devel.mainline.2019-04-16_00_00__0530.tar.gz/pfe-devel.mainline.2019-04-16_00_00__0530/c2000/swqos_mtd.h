#ifndef _MODULE_SWQOS_MTD_H_
#define _MODULE_SWQOS_MTD_H_

#include "types.h"

typedef struct hif_swqos_hdr {
	u8	client_id;
	u8	swqueue;
	u8	hwqueue;
	u8	output_port;
	u8	dmem_offset;
	u8	pkt_offset;
	u16	le_length;
} __attribute__((aligned(8))) hif_swqos_hdr_t;

typedef struct swqos_mtd_t
{
	struct swqos_mtd_t	*next;
	void	*data;		// start of packet buffer
	union {
	    struct hif_swqos_hdr swqos_hdr;
	    struct {
		u8  client_id;	// unused
		u8  queue;	// swqueue
		u8  hwqueue;
		u8  output_port;
		u8  dmem_offset;
		u8  pkt_offset;
		u16 length;	// le_length
	    };

	};
} __attribute__((aligned(16))) SWQOS_MTD, *PSWQOS_MTD;

#endif	// _MODULE_SWQOS_MTD_H_
