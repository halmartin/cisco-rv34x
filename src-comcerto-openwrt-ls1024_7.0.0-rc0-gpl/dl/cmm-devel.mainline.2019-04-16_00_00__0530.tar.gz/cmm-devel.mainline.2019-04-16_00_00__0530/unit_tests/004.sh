#!/bin/sh

cmm -c show stat interface lan query
#returns ERROR: Unexpected returned result from FPP rc:044c
