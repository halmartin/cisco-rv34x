#!/bin/sh

cmm -c set voicebuf load 5 8 160 ./voicebuf
cmm -c set voicebuf unload 5