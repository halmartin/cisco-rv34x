#!/bin/sh

cmm -c set rx interface eth0 bridge on
