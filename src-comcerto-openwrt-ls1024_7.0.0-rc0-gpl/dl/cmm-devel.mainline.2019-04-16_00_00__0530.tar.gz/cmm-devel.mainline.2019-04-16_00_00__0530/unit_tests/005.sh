#!/bin/sh

cmm -c query rtcp sock_id 1 reset
