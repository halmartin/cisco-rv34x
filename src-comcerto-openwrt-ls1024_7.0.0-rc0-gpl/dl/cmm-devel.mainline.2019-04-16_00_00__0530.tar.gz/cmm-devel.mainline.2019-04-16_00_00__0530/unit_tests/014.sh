#!/bin/sh

cmm -c show rx interface eth0 icc
#returns "ERROR: Unexpected returned result from FPP rc:fffe"
