#!/bin/sh

cmm -c set natpt open sock_id_a 1 sock_id_b 2 4to6
#returns "Error 1212 received from FPP"
