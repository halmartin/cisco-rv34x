#!/bin/sh

cmm -c query rx bridge

