#!/bin/sh

cmm -c set rtp open ccn 1 sock_id_a 1 sock_id_b 2
