#!/bin/sh

cmm -c set socket close sock_id 1
cmm -c set socket close sock_id 2
