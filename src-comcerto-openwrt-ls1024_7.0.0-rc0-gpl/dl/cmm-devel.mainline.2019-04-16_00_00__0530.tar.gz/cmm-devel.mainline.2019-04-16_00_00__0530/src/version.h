/* Auto-generated file. Do not edit tag_rv34x_mr1_v1.0.03.14 */
#ifndef VERSION_H
#define VERSION_H

#define CMM_VERSION "tag_rv34x_mr1_v1.0.03.14"

#endif /* VERSION_H */
