/*
  *  bitlist.h: bitlist and bitarray utility functions
  *
  *  Copyright (C) 2015 Freescale Semiconductor, Inc.
  *
  * This program is free software; you can redistribute it and/or modify
  * it under the terms of the GNU General Public License as published by
  * the Free Software Foundation; either version 2 of the License, or
  * (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  * GNU General Public License for more details.
  *
  * You should have received a copy of the GNU General Public License
  * along with this program; if not, write to the Free Software
  * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
  */

#ifndef __BITLIST_H__
#define __BITLIST_H__

#include <stdint.h>

// ============================================================================
//
// get_highest_bit
//
// This inline function uses the GCC built-in function __builtin_clz() to find the first bit set in a 32-bit value,
// starting with the left-most bit.
//
// It returns the bit number of the first bit set, where the MSB is bit 31, and the LSB is bit zero.  If none of the
// bits are set, it returns the value -1.
//
// Note that __builtin_clz(0) is undefined, so we do a special check for val == 0.

static inline int get_highest_bit(uint32_t val)
{
	if (val <= 2)
		return (int)val - 1;
	return 31 - (int)__builtin_clz(val);
}

// ============================================================================
//
// bitarray routines
//
// A bitarray is stored as an array of uint32_t's, where bit 0 of the array is bit 0 of the first word
//
// ============================================================================

#define BITARRAY_DECLARE(bitarray, nbits) uint32_t bitarray[(nbits + 31) / 32]

#define bitarray_clear(bitarray, nbits) do {		\
	int i;						\
	for (i = 0; i < (nbits + 31) / 32; i++)		\
		bitarray[i] = 0;			\
} while (0)

static inline int bitarray_get_highest(uint32_t *bitarray, int nbits)
{
	int wordnum, bitnum;
        for (wordnum = (((nbits) + 31) / 32) - 1, bitnum = ((nbits) & 31) == 0 ? 32: ((nbits) & 31); wordnum >= 0; wordnum--, bitnum = 32)
	{
                bitnum = get_highest_bit((0xFFFFFFFF >> (32 - bitnum)) & bitarray[wordnum]);
		if (bitnum >= 0)
			return wordnum * 32 + bitnum;
	}
	return -1;
}

#define bitarray_setbit(bitarray, bitnum) (bitarray[(bitnum) / 32] |= 1 << ((bitnum) & 31))
#define bitarray_clrbit(bitarray, bitnum) (bitarray[(bitnum) / 32] &= ~(1 << ((bitnum) & 31)))
#define bitarray_testbit(bitarray, bitnum) ((bitarray[(bitnum) / 32] & (1 << ((bitnum) & 31))) != 0)

/** Loops over all set bits in a bitarray
*
* @param bitarray	array name
* @param index		index variable -- contains current array bit number
* @param nbits		number of bits in array
*/
#define bitarray_for_each(bitarray, nbits, index)	\
        for (index = bitarray_get_highest(bitarray, nbits); (int)(index) >= 0; index = bitarray_get_highest(bitarray, index))

/** Loops over set bits in a bitarray, starting at the given start bit
*
* @param bitarray	array name
* @param index		index variable -- contains current array bit number
* @param startbit	bit number to start loop at
*/
#define bitarray_for_each_subset(bitarray, index, startbit)  \
        for (index = (startbit); (int)(index) >= 0; index = bitarray_get_highest(bitarray, index))

// ============================================================================
//
// bitlist routines
//
// A bitlist is stored as a bitarray plus a bitlist structure which holds the number of bits
//	and the value of the most-significant set bit number.
//
// ============================================================================

typedef struct {
	short	number_of_bits;
	short	max_setbit;
} bitlist_t, *bitlist_ptr_t;

#define BITLIST_DECLARE(name, nbits) bitlist_t name##_bitlist; BITARRAY_DECLARE(name##_bitarray, nbits)

#define bitlist_init(name, nbits) do {					\
	bitarray_clear(name##_bitarray, nbits);					\
	name##_bitlist.number_of_bits = nbits;				\
	name##_bitlist.max_setbit = -1;					\
} while (0)

#define bitlist_init_from_bitarray(listname, bitarray, nbits) do {	\
	int i;								\
	for (i = 0; i < (nbits + 31) / 32; i++)				\
		listname##_bitarray[i] = bitarray[i];	\
	listname##_bitlist.number_of_bits = nbits;			\
	listname##_bitlist.max_setbit = bitarray_get_highest(listname##_bitarray, nbits);	\
} while (0)

#define bitlist_get_highest_subset(name, nbits) bitarray_get_highest(name##_bitarray, nbits)

#define bitlist_get_highest(name) (name##_bitlist.max_setbit)

#define bitlist_setbit(name, bitnum) do {		\
	bitarray_setbit(name##_bitarray, bitnum);			\
	if ((int)(bitnum) > name##_bitlist.max_setbit)	\
		name##_bitlist.max_setbit = bitnum;	\
} while (0)

#define bitlist_clrbit(name, bitnum) do {		\
	bitarray_clrbit(name##_bitarray, bitnum);			\
	if ((int)(bitnum) >= name##_bitlist.max_setbit)	\
		name##_bitlist.max_setbit = bitarray_get_highest(name##_bitarray, name##_bitlist.max_setbit);	\
} while (0)

#define bitlist_testbit(name, bitnum) bitarray_testbit(name##_bitarray, bitnum)

/** Loops over set bits in a bitlist, starting at the given start bit
*
* @param name		bitlist name
* @param index		index variable -- contains current array bit number
* @param startbit	bit number to start loop at (must be set)
*/
#define bitlist_for_each_subset(name, index, startbit) bitarray_for_each_subset(name##_bitarray, index, startbit)

/** Loops over all set bits in a bitlist, starting at the most-significant set bit
*
* @param name		bitlist name
* @param index		index variable -- contains current array bit number
*/
#define bitlist_for_each(name, index) bitarray_for_each_subset(name##_bitarray, index, name##_bitlist.max_setbit)

#endif // __BITLIST_H__

