#ifndef CAPPORTALD_H
#define CAPPORTALD_H 1

#include <stdint.h>
#include<stdio.h>
#ifdef MULTI_THREADING
#include <pthread.h>
#endif
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <netinet/ip.h>
#include "libtree.h"
#include "cp_main.h"


#define IFNAMSIZ 16
#define NF_RULE_LEN     254
#define URL_LEN         127
#define SUCCESS_URL_LEN URL_LEN
#define SPLASH_URL_LEN  URL_LEN
#define VAP_IF_NAME_LEN 11
#define MAC_ADDR_LEN    6
#define MAX_PRO_NAME_SIZE 64
#define USERNAME_SIZE 127
#define PASSWORD_SIZE 127
#define CP_PROFILE_FILE "/tmp/etc/config/coovachilli"
#define SIZE 512
#define BSIZE 125
#define CMD_SIZE 128

#define INFINITE_TIMEOUT 0xFFFFFFFF

#define MAX_NUM_VAPS 	15
#define MAX_NUM_WLAN    2
#define SSID_STR_LEN    32
#define STATUS_BUF_SIZE 100000
#define VLAN_MAX  32
#define WINDOW_TIMEOUT 3000

#define STATUS_TYPE_SIMPLE  1
#define STATUS_TYPE_COMPLEX  2

char buffer[STATUS_BUF_SIZE];

typedef enum client_state
{
    CLIENT_STATE_START = 0,
    UNAUTHENTICATED,
    AUTHENTICATING,
    AUTHORIZED,
    AUTHENTICATED,
    LOGGED_OFF,
    CLIENT_STATE_END
} client_state_e;

typedef struct client_state_s
{
    client_state_e current;
    client_state_e next;
} client_state_t;

typedef struct net_filter_rules
{
    char rule_cmd[NF_RULE_LEN + 1];
} nf_rules_t;

typedef struct nw_addr
{
    uint8_t mac[MAC_ADDR_LEN + 1];
    struct in_addr ipv4;
} nw_addr_t;

typedef struct session_time
{
    time_t start;
    time_t end;
} session_time_t;

typedef struct session_vars
{
    uint32_t bw_limit;
    unsigned long rx_bytes;
    unsigned long tx_bytes;
} session_vars_t;

typedef struct user_cred
{
    char username[USERNAME_SIZE + 1];
    char password[PASSWORD_SIZE + 1];
} user_cred_t;

typedef enum user_type
{
    GENERAL_USR = 1,
    LOBBY_USR
} user_type_e;


typedef struct client_list
{
#ifdef MULTI_THREADING
    pthread_mutex_t lock;
#endif
    nw_addr_t client_addr;
    client_state_t state;
    session_time_t session_time;
    session_vars_t session_var;
    nf_rules_t *nf_rules;
    user_cred_t pam_data;
	user_type_e cp_user;
	unsigned long lobby_time_exp;
    uint8_t initialized;
    char vap_if_name[VAP_IF_NAME_LEN + 1];
} client_list_t;

typedef struct client_node
{
    struct bstree_node node;
    client_list_t client;
} client_node_t;

typedef struct well_knwon_info
{
    char ssid[SSID_STR_LEN+1];
    char br_name[IFNAMSIZ];
    nw_addr_t ap_addr;
} wki_t;

typedef struct capportal_cfg
{
    char enabled;
	int  ssid_enabled; //0:disable ssid;1:enable ssid
	char update_flag;
	char info_url[SPLASH_URL_LEN+1];
    char splash_url[SPLASH_URL_LEN+1];
    char redir_url[SUCCESS_URL_LEN + 1];
    wki_t wki;
    int auth;
    int timeout;
    int cloud_provider;
    char captive_profile_name[MAX_PRO_NAME_SIZE+1];
} capportald_cfg_t;

typedef struct capportald_prof
{
    char profile_name[MAX_PRO_NAME_SIZE+1];
    capportald_cfg_t cp_cfg;
} capportald_prof_t;

typedef struct redirect_msg
{
    uint8_t use_ssl;
    wki_t *wki;
    nw_addr_t *client_addr;
    char *redirect_url;
} redir_msg_t;

extern capportald_cfg_t cp_cfg[VAP_END];
extern capportald_prof_t cp_prof_cfg[VAP_END];

#endif				/* CAPPORTALD_H */
