#ifndef _CP_CLIENT_LIST_H
#define _CP_CLIENT_LIST_H 1

#include "cp_main.h"
#include "capportald.h"

client_node_t * cp_client_present_check(char *,int );
client_node_t * cp_client_present_ip_check(uint32_t ,int );
void _cp_client_list_init (int i);
int cp_client_list_init (void);
void cp_schedule_task (uint32_t ipaddr, int vap,int time);
int cp_client_state_change_with_ip(uint32_t ip_addr,int new_state,int vap);
void cp_cancel_session_timer(uint32_t ip_addr,int vap);
void cp_cancel_inactivity_timer(uint32_t ip_addr,int vap);
void cp_schedule_session_timer(uint32_t ip_addr,int vap,int time);
void cp_schedule_inactivity_timer(uint32_t ip_addr,int vap,int time);



typedef enum bst_action_e {
    INSERT = 0,
    INSERT_MAC,
    INSERT_IP,
    REMOVE,
    PRINT
} bst_action_t;

typedef enum rm_client_by_action {
    DISCONNECT = 0,
	SSID_CONF_CHANGE,
    IDLE_TIMEOUT,
    WLAN_DISASSOC
} rm_client_by_action_t;


#define CLIENT_TIMEOUT 1*60

#endif
