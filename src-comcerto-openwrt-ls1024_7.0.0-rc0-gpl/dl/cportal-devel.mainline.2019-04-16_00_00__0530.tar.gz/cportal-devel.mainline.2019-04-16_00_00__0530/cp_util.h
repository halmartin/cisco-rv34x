#ifndef _CP_UTIL_H
#define _CP_UTIL_H 1

#define MAC_ADDR_STR_LEN     17
#define IP_ADDR_STR_LEN 17

void *safe_memset (void *data, int ch, int size);
void *safe_malloc (int size);
void *safe_memset (void *data, int ch, int size);
int safe_memcpy (void *dest, void *src, int size);
int safe_memcmp (void *one, void *two, int size);
char *mactoa (uint8_t * hw_addr);
int file_exist (char *filename);

#endif
