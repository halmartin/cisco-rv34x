/** @file cportalctl_thread.h
  @brief cportal monitoring thread
  */

#ifndef _CPORTALCTL_THREAD_H_
#define _CPORTALCTL_THREAD_H_


#define DEFAULT_CPORTALCTL_SOCK	"/tmp/cportalctl.sock"

/** @brief Listen for cportal control messages on a unix domain socket */
void *thread_cportalctl(void *arg);


#endif
