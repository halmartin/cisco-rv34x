#include "cp_main.h"
#include "cp_client_list.h"
#include "cp_socket_init.h"
#include "ssl.h"
#include "cp_nf_rules.h"
#include "cp_client_list.h"
#include "cp_util.h"
#include "capportald.h"

#define AGENT_TYPE1 0x01
#define TEMP_SIZE 50

int conn_fd;
usockaddr client_addr;

static char auth_buf[10000];
static const char default_landing_url[] = "http://google.com";

static char *
get_filename (char *name)
{
    char *buf = NULL;
    buf = index(name, (int) '/');
    if (buf == NULL) {
        return NULL;
    }
    return buf;
}

char *get_username (char *username)
{
    char *tmp = NULL;
    tmp = strstr(username, "user_name=") ;
    tmp = index(tmp, (int) '=');
    return tmp;
}

static char *login_page_files[] = {"login.html", "logo.jpg", "logo.png", "logo.gif", "logo.bmp", "bg.jpg", "bg.png", "bg.gif", "bg.bmp", "jquery.min.js", "guest_info.html", "Status_information_icon.png", "Status_information_icon.gif", "opacity67.png", "fonts/CiscoSansTTRegular.woff", "fonts/fontawesome-webfont.woff", "fonts/fontawesome-webfont.woff2", "fonts/fontawesome-webfont.ttf",NULL};
static int
cp_parse_header (char *buf)
{
    char *request = NULL;
    int rc,len = 0;

    CP_ERROR(1, "Entering %s(), buf = \"%s\"", __func__, buf);
   	request = strstr (buf,"Host:");
	
    if (request == NULL)
    {
        return FAILURE;
    }
    else
    {
    	len = strlen(buf)-strlen(request);
		request = malloc(len);
		memset(request,0,len);
		memcpy(request,buf,len);
        CP_ERROR(1, "%s:%d request=%s\n", __func__, __LINE__, request);
        if (strstr(request, SOCIAL))
        {
            rc = SOCIAL_CODE;
        }
        else if (strstr(request, LOGIN))
        {
            rc = LOGIN_CODE;
        }
        else if (strstr(request, LOGOFF))
        {
            rc = LOGOFF_CODE;
        }
        else if (strstr(request, LOGOUT))
        {
            rc = LOGOUT_CODE;
        }		
        else if (strstr(request, AUTH_TOKEN)) {
            rc = LOGIN_CODE;
        }
		else if (strstr(request, CPORTAL)) {
			rc = CPORTAL_CODE;
		}
		else if (strstr(request, GETINFO)) {
			rc = CPORTAL_INFO;
		}
        else
        {
            rc = FAILURE;
        }
		
		free(request);
        return rc;
    }
}

/* FIXME: This is happening in the child process, hence the state
 * change is not reflecting in the prarent process */
static int 
cp_move_login (nw_addr_t * cli, int vap, void *conn, int do_ssl, char *landing_url)
{
    cp_flush_client_rules (vap, mactoa(cli->mac));
    if (cp_add_client_allow_rule (vap, mactoa(cli->mac)) == FAILURE)
    {
        CP_ERROR (1, "Client allow rules init failed");
        return FAILURE;
    }

    if(cp_success_redir(cli,conn,do_ssl,landing_url,vap,LOGIN_CODE)==FAILURE){
        CP_ERROR(1,"client success redir failed");
        return FAILURE;
    }

    cp_flush_client_route (vap, mactoa(cli->mac));

    return SUCCESS;
}

static int
cp_move_logoff (nw_addr_t * cli, int vap)
{
	char cmd_str[CMD_SIZE] = {'\0'};    
        FILE *fp = NULL;
	/* Delete the cportal pid file if lobby user is logoff manually */
       	sprintf(cmd_str,"find /tmp/cportal.* -type f -exec grep -H \'%x\' \{\} \\\; \| cut -d \: -f 1",cli->ipv4.s_addr);
	if(fp = popen(cmd_str,"r")) {
		memset(cmd_str,0,CMD_SIZE);
		/* Processing only for lobby user */
		if (fgets(cmd_str,CMD_SIZE,fp) && strcmp(cmd_str,"find: /tmp/cportal.*: No such file or directory")) {
			memmove(cmd_str+6,cmd_str,sizeof(cmd_str));
			fclose(fp);                    
                        strncpy(cmd_str,"rm -f ",6);   
                        system(cmd_str);
			/* Calling timeout handler and making timeout 0 */
                        cp_cancel_inactivity_timer(cli->ipv4.s_addr,vap);                                 
			cp_schedule_inactivity_timer(cli->ipv4.s_addr,vap,0);
		}
	}                                      
	
	if (cp_client_state_change_with_ip (cli->ipv4.s_addr, UNAUTHENTICATED, vap) == FAILURE)
	{
		CP_ERROR (1, "Client state change failed");
		return FAILURE;
	}

	cp_flush_client_rules (vap, mactoa(cli->mac));
	cp_syslog(LOG_NOTICE, "Client %s (%s) on SSID \"%s\" (%s) de-authenticated due to disconnect action applied by user",
            	inet_ntoa(cli->ipv4), mactoa(cli->mac), cp_cfg[vap].wki.ssid,
            	gVapWlanMap[vap]);
	
	return SUCCESS;
}

int
cp_drop_request (nw_addr_t * cli)
{
    return;
}

/* Converts a hex character to its integer value */
char from_hex(char ch) {
    return isdigit(ch) ? ch - '0' : tolower(ch) - 'a' + 10;
}

/* Returns a url-decoded version of str */
/* IMPORTANT: be sure to free() the returned string after use */
char *url_decode(char *str) {
    char *pstr = str, *buf = malloc(strlen(str) + 1), *pbuf = buf;
    while (*pstr) {
        if (*pstr == '%') {
            if (pstr[1] && pstr[2]) {
                *pbuf++ = from_hex(pstr[1]) << 4 | from_hex(pstr[2]);
                pstr += 2;
            }
        } else if (*pstr == '+') { 
            *pbuf++ = ' ';
        } else {
            *pbuf++ = *pstr;
        }
        pstr++;
    }
    *pbuf = '\0';
    return buf;
}

int cp_update_client_rule(nw_addr_t * cli, int vap)
{
    cp_flush_client_rules ((vap_if_index_t)vap, mactoa(cli->mac));
    if (cp_add_client_allow_rule ((vap_if_index_t)vap, mactoa(cli->mac)) == FAILURE)
    {
        CP_ERROR (1, "Client allow rules init failed");
        return FAILURE;
    }
    return SUCCESS;
}
void cportal_load(void *conn, int do_ssl,char *file,int index)
{
	char filename[256];
	char *buffer;
	int rc = 0;
	FILE *fd = NULL;
	struct stat st;
	char http_code[] =   "HTTP/1.1 200 OK \r\n";
	char *http_cont;
	char http_connection[] = "Connection: Keep-Alive\r\n\r\n";
	int len ;
	if(strstr(file,".js") || strstr(file,".png")){
		http_cont =   "Content-Type: text/plain; charset=UTF-8\r\n";
	}else if(strstr(file,".html")){
		http_cont =   "Content-Type: text/html; charset=UTF-8\r\n";
	}else if(strstr(file,".jpg")){
		http_cont =   "Content-Type: text/jpeg; charset=UTF-8\r\n";
	}else{
		http_cont =   "Content-Type: text/html; charset=UTF-8\r\n";
	}
	len = strlen(http_cont) + strlen(http_code) + strlen(http_connection);
	snprintf(filename,256,"/tmp/www/%s/%s",cp_cfg[index].captive_profile_name,file);

	fd = fopen(filename,"r");
	if(fd == NULL){
		CP_INFO(1,"File opening failed %s",filename);
		return;
	}
	rc = stat(filename,&st);
	if(rc == -1){
	fclose(fd);
		CP_INFO(1,"Stat failed \n");
		return;
	}
	buffer = malloc(st.st_size+1+len);
	memset(buffer,0,st.st_size+1+len);

	strcpy(buffer,http_code);
	strcat(buffer,http_cont);
	strcat(buffer,http_connection);

	rc = fread(buffer+len,st.st_size+1,1,fd);
	if(rc < 0){
		CP_INFO(1,"fread railed");
		fclose(fd);
		free(buffer);
		return;
	}
 
	if(cp_send(conn,buffer,st.st_size+len,do_ssl)< 1){
		free(buffer);
		fclose(fd);
		CP_INFO(1,"cp_send failed\n");
		return;
	}
		fclose(fd);
	free(buffer);
	return ;
}

int cportal_info(void *conn,client_node_t *node,int do_ssl,int vap)
{
	char *buffer, *body;
	int len, content_len;
	int timeout = 120;
	char file_path[120];
	int window_flag=1;
	client_node_t *node_local;

	memset(file_path,0,sizeof(file_path));
	sprintf(file_path,"/tmp/cportal_getinfo_%0x",node->client.client_addr.ipv4);

	
	if (file_exist (file_path)) {
		remove(file_path);
	} else {
		window_flag=0;
	}
	

	node_local = (client_node_t *) cp_client_present_ip_check(node->client.client_addr.ipv4.s_addr,vap);
	
	if( node_local == NULL ) {
		CP_INFO(1,"%s(%d) can't find the node\n",__FUNCTION__,__LINE__);
		return FAILURE;
	} 
	
	content_len = asprintf (&body,
				"{\"output\":{\"connected-time\":\"%d\",\"window_timeout\":\"%d\",\"window_flag\":\"%d\"}}",
				(time(NULL)-node_local->client.session_time.start),WINDOW_TIMEOUT,window_flag);
	

	if (content_len < 1) {
		CP_ERROR (1, "Content generate asprintf failed");
		return FAILURE;
	}
	len = asprintf (&buffer,
            "HTTP/1.1 200 OK\r\n"
            "Cache-Control: private\r\n"
            "Content-Type: application/json;charset=utf-8\r\n"
            "Content-Length: %d\r\n"
            "Connection: close\r\n\r\n"
            "%s",content_len, body);
	free(body);
    
	len = cp_send(conn, buffer, len+1,do_ssl);
	if (len < 1)
	{
		free(buffer);
		CP_ERROR (1, "%s(): Response writting failed", __func__);
		return FAILURE;
	}
	else
	{
		CP_ERROR (1, "Response writting success");
	}
	free(buffer);
	node->client.session_time.end = (time_t) timeout;
	return SUCCESS;
}

char *parse_file(char *buf)
{
	char *header;
	int i = 0;
	char *rc = NULL;
	header = strchr(buf,'\n');

	*header = '\0';

	CP_INFO(1,"Header %s",buf);
	
	for (i=0;login_page_files[i]!=NULL;i++)
	{
		rc = strstr(buf,login_page_files[i]);
		if(rc)
			return login_page_files[i];
	}
	return NULL;
}

uint8_t is_lobby_user(char *user) {
	char uci_cmd_str[TEMP_SIZE] = {'\0'};
	FILE *fp = NULL;
	char str[TEMP_SIZE] = {'\0'};
	char temp[SIZE] = {'\0'};
	char *ptr = NULL;
	int len;
	uint8_t ret = FALSE;
	
	snprintf(uci_cmd_str, sizeof(uci_cmd_str),"uci show lobby");
	fp = popen(uci_cmd_str,"r");
	if ( fp == NULL) {
        	CP_ERROR(1, "Error in running %s command", uci_cmd_str);
        	return FALSE;
	}
	while (fgets(temp, SIZE, fp) != NULL) {
		memset(str,0,TEMP_SIZE);
		if ( (ptr= strstr(temp, "username=")) ) { /* get username */
			ptr = ptr+9;
			len = strlen(ptr);
			len = len - 1;
			strncpy(str,ptr,len);
			if( 0 == strcmp(user,str) ) {
				ret = TRUE;
				break;
			}
        	} 
	}
	
	fclose(fp);
	return ret;	
}

/*username, password and ssid should be same*/
uint8_t lobby_user_authenticate(client_node_t *node, char *connName) {
	char uci_cmd_str[BSIZE] = {'\0'};
    FILE *fp = NULL;
	char lobby_exp_str[20] = {'\0'};
	char temp[SIZE] = {'\0'};
	char *ptr = NULL;
	int len;	
	uint8_t ret = FALSE;
	
	/*compare password with uci configs*/
	snprintf(uci_cmd_str, sizeof(uci_cmd_str),"uci show lobby.%s.password 2>&1",node->client.pam_data.username);
	fp = popen(uci_cmd_str,"r");
	if ( fp == NULL) {
		CP_ERROR(1, "Error in running %s command", uci_cmd_str);
		return FALSE;
	}
	if (fgets(temp, SIZE, fp) != NULL) {
		if ( 0 == strcmp(temp,"uci: Entry not found")) 
			goto false_out;
		memset(uci_cmd_str,0,sizeof(uci_cmd_str));
		snprintf(uci_cmd_str, sizeof(uci_cmd_str), "lobby.%s.password=\'%s\'",node->client.pam_data.username,node->client.pam_data.password);
		if ( 0 != strncmp(uci_cmd_str,temp,strlen(uci_cmd_str)) )
			goto false_out;
	} else {
		goto false_out;
	}
	fclose(fp);

	/*compare ssid with uci configs*/
	memset(uci_cmd_str,0,sizeof(uci_cmd_str));
	snprintf(uci_cmd_str, sizeof(uci_cmd_str),"uci show lobby.%s.ssid 2>&1",node->client.pam_data.username);
	fp = popen(uci_cmd_str,"r");
	if ( fp == NULL) {
		CP_ERROR(1, "Error in running %s command", uci_cmd_str);
		return FALSE;
	}
	if (fgets(temp, SIZE, fp) != NULL) {
		if ( 0 == strcmp(temp,"uci: Entry not found")) 
			goto false_out;
		memset(uci_cmd_str,0,sizeof(uci_cmd_str));
		snprintf(uci_cmd_str, sizeof(uci_cmd_str), "lobby.%s.ssid=\'%s\'",node->client.pam_data.username,connName);
		if ( 0 != strncmp(uci_cmd_str,temp,strlen(uci_cmd_str)) )
			goto false_out;
	} else {
		goto false_out;
	}	

	fclose(fp);
	
	memset(uci_cmd_str,0,sizeof(uci_cmd_str));
	snprintf(uci_cmd_str, sizeof(uci_cmd_str),"uci show lobby.%s.expirestr",node->client.pam_data.username);
	fp = popen(uci_cmd_str,"r");
	if ( fp == NULL) {
		CP_ERROR(1, "Error in running %s command", uci_cmd_str);
		return FALSE;
	}	
	if (fgets(temp, SIZE, fp) != NULL) {
		if ( 0 == strcmp(temp,"uci: Entry not found")) 
			goto false_out;
		
		ptr = strstr(temp,"=");
		if ( ptr == NULL ) 
			goto false_out;
		ptr = ptr + 2;//skip =' character

		//format 460616032017====>2017.03.16-06:46
		strncpy(lobby_exp_str+14,ptr,2);//min 2 characters
		lobby_exp_str[13]=':';
		
		strncpy(lobby_exp_str+11,ptr+2,2);//hour 2 characters
		lobby_exp_str[10]='-';
		strncpy(lobby_exp_str+8,ptr+4,2);//day 2 characters
		lobby_exp_str[7]='.';
		strncpy(lobby_exp_str+5,ptr+6,2);//mon 2 characters
		lobby_exp_str[4]='.';
		strncpy(lobby_exp_str,ptr+8,4);//year 4 characters
		CP_ERROR(1, "%s(%d)type=%d,exp_time=%s\n", __FUNCTION__,__LINE__,node->client.cp_user,lobby_exp_str);
	} else {
		goto false_out;
	}		

	fclose(fp);
	
	memset(uci_cmd_str,0,sizeof(uci_cmd_str));
	snprintf(uci_cmd_str, sizeof(uci_cmd_str),"date --date=\"%s\" +%%s",lobby_exp_str);
	fp = popen(uci_cmd_str,"r");
	if ( fp == NULL) {
		CP_ERROR(1, "Error in running %s command", uci_cmd_str);
		return FALSE;
	}
	if (fgets(temp, SIZE, fp) != NULL) {
		node->client.cp_user = LOBBY_USR;
		sscanf(temp,"%lu",&(node->client.lobby_time_exp));
		CP_ERROR(1, "%s(%d)type=%d,exp_time=%s,exp_time_sec=%lu\n", __FUNCTION__,__LINE__,node->client.cp_user,lobby_exp_str,node->client.lobby_time_exp);
		fclose(fp);
		if((time(NULL) >  node->client.lobby_time_exp)) {
			CP_ERROR(1, "%s(%d)now is=%lu,exp=%lu\n", __FUNCTION__,__LINE__,time(NULL),node->client.lobby_time_exp);
			goto false_out;
		}
		return TRUE;
	} else {
		goto false_out;
	}

false_out:
	fclose(fp);
	return FALSE;

}


/**
 * Parses the header for internal.
 * return FAILURE, if unable to parse.
 * return SUCCESS, if parsing is successful
 **/
int parse_internal_header(void *conn, int do_ssl, int vap, client_node_t *node, int *timeout)
{
    int ret = FAILURE;
    char *parse_ptr = NULL;
    char *token = NULL;
    char *saveptr = NULL, *tmp = NULL;
    char *p_landing_url = NULL;
    char *landing_url = (char *) default_landing_url;
    char *landing_url_tmp = (char *) default_landing_url;
    int len = 0;
    nw_addr_t *cli = &node->client.client_addr;
    char *dec_content = NULL;
	int decode_flag = 0;


    ret = cp_parse_header (auth_buf);
    switch (ret) {
        case LOGIN_CODE:
            CP_INFO(1,"Its login request");
            if ((tmp = strstr(auth_buf, LANDING_URL)) != NULL) {
                dec_content = url_decode(tmp);
				decode_flag = 1;
                parse_ptr = dec_content; 
                parse_ptr += strlen(LANDING_URL) + 1;
                tmp = strtok_r (parse_ptr,"&", &saveptr);
                if (tmp != NULL) {
                    landing_url_tmp = tmp;
                }

                if (landing_url_tmp == NULL) {
                    /* Fallback to default landing URL */
                    landing_url_tmp = (char *) default_landing_url;
                }
            }
			
			if( decode_flag == 0 ) {
					tmp = auth_buf;
					saveptr = url_decode(tmp);
					decode_flag = 1;
			}
            if ((tmp = strstr(saveptr, USERNAME)) != NULL) {
                tmp += strlen(USERNAME) + 1;
                if (*tmp == '&') {
                    strcpy(node->client.pam_data.username,"");
                } else {
                    /* need to store username */
                    token = strtok_r (tmp,"&", &saveptr);
                    if (token != NULL) {
                        CP_INFO (1,"username - %s\n", token);
                        strncpy(node->client.pam_data.username, token, USERNAME_SIZE);
                    }
                }
            }

            if (cp_cfg[vap].auth == 1) {
                if ((tmp = strstr(saveptr, LOGIN_PASSWORD)) != NULL) {
                    tmp += strlen(LOGIN_PASSWORD) + 1;
                    token = strtok_r (tmp,"&", &saveptr);
                    if (token != NULL) {
			if(tmp[0] == '&') {
				CP_INFO (1,"password - EMPTY\n");
				strncpy(node->client.pam_data.password, "", PASSWORD_SIZE);
			} else {
                        	CP_INFO (1,"password - %s\n", token);
	                        strncpy(node->client.pam_data.password, token, PASSWORD_SIZE);
			}
                    }
                }
				ret = is_lobby_user(node->client.pam_data.username); //ret=TRUE, is lobby user; ret=FALSE, other user
				if (ret == TRUE) {
                	ret = lobby_user_authenticate(node,cp_cfg[vap].wki.ssid);
				} else {
					node->client.cp_user = GENERAL_USR;
					ret = authenticate("ssid",node->client.pam_data.username,node->client.pam_data.password,cp_cfg[vap].wki.ssid);
				}
				if ( ret != 1) {
                    CP_INFO(1,"Authentication failed\n");
		    		len = asprintf(&landing_url, "%s?landing_url=https://%s", cp_cfg[vap].splash_url,inet_ntoa(cp_cfg[vap].wki.ap_addr.ipv4));
					cp_syslog(LOG_NOTICE, "Client %s (%s) on SSID \"%s\" failed to authenticate.",
                        inet_ntoa(node->client.client_addr.ipv4), mactoa(node->client.client_addr.mac),
                        cp_cfg[vap].wki.ssid);
		    		cp_success_redir(cli,conn,do_ssl,landing_url,vap,LOGIN_ERR_CODE);
                    free(dec_content);
                    break;
                }
            }
			p_landing_url = strstr(landing_url_tmp,"resp=1");
			
			if (NULL != p_landing_url) {
			*p_landing_url = 0x0;
			}
			
			if (strcmp(cp_cfg[vap].redir_url,"") != 0 ) {
                landing_url_tmp = cp_cfg[vap].redir_url;
            }
			
	    	landing_url = landing_url_tmp;
            ret = cp_move_login (cli, vap, conn, do_ssl, landing_url);
            ret  = (ret == SUCCESS) ? AUTHENTICATED : FAILURE;
			memset(dec_content,0,sizeof(dec_content));
			sprintf(dec_content,"echo 0 > /tmp/cportal_getinfo_%0x",node->client.client_addr.ipv4);
			system(dec_content);
            free(dec_content);
            break;
        case LOGOFF_CODE:
            CP_INFO(1,"its logoff request");
            ret = cp_move_logoff (cli, vap);
            ret = (ret == SUCCESS) ? LOGGED_OFF : FAILURE;
            break;
		case LOGOUT_CODE:
			CP_INFO(1,"its logout request");
			ret = cp_move_logoff (cli, vap);
			len = asprintf(&landing_url, "%s?landing_url=https://%s", cp_cfg[vap].splash_url,inet_ntoa(cp_cfg[vap].wki.ap_addr.ipv4));
			cp_success_redir(cli,conn,do_ssl,landing_url,vap,LOGOUT_CODE);			
			ret = (ret == SUCCESS) ? LOGGED_OFF : FAILURE;
			break;
        case SOCIAL_CODE:
            CP_INFO(1,"its social login request");
            ret = AUTHORIZED;
            break;
		case CPORTAL_CODE:
	    	CP_INFO(1,"its captive portal page request %s",auth_buf);
	    	char *file = NULL;
	    	file = parse_file(auth_buf);
	    	if(file){
		    	cportal_load(conn,do_ssl,file,vap);
            } else {
                char n_file[128] = {0};
                char *p = auth_buf;
                char p_len = 0;
                char *p_head = NULL;

                p = strstr(auth_buf, "GET ");
                if (p == NULL)
                    break;
                p += 4;

                while (*p && *p != '\n' && *p != ' ' && *p != '?') {
                    p++;
                }

                p_head = p;

                while (p != auth_buf) {
                    if (*p != '/') {
                        p_head--;
                        p_len++;
                    } else {
                        p_head++;
                        p_len--;
                        break;
                    }

                    p--;
                }

                if (p_len > 0) {
                    strncpy(n_file, p_head, p_len);

                    cportal_load(conn, do_ssl, n_file, vap);
                }
            }
	    	break;
		case CPORTAL_INFO:
			CP_INFO(1,"%s(%d)its getinfo request\n",__FUNCTION__,__LINE__);
			ret = cportal_info(conn,node,do_ssl,vap);
		break;
		default:
            CP_ERROR(1,"UNKNOWN request");
            ret = FAILURE;
    }
    return ret;
}

static int agent_type(void)
{
	char *p = NULL;
	char *q = NULL;
	char agent_buf[100] = {'\0'};
	int len=0;

	p = strstr(auth_buf,"POST /logon HTTP/1.1");
	if(p == NULL)
		return -1;
	p = strstr(auth_buf,"username=");
	if(p == NULL) {
		return AGENT_TYPE1;
	}

	return -1;
}
static int
handle_req (void *conn, int do_ssl, client_node_t * node, int vap)
{
    int ret = 0, timeout = 120;
    int sock = do_ssl ? ((openssl_con *) conn)->sock : (int) conn;

    if (ndelay_off(sock) < 0) {
        CP_ERROR(1, "Error setting Non-blocking mode for fd (%d)", sock);
    }

    memset ((void *) auth_buf, 0, sizeof(auth_buf));
    ret = my_read(conn, do_ssl, auth_buf, sizeof(auth_buf));
    if (ret <= 0) {
        CP_ERROR(1, "%s(): Handling login request failed", __func__);
        return FAILURE;
    }
	ret = agent_type();
	if ( AGENT_TYPE1 ==  ret) {
		ret = strlen(auth_buf);
		ret = my_read(conn, do_ssl, (auth_buf+ret), (sizeof(auth_buf)-ret));
	}

    CP_INFO(1, "Handling login request, buf = \"%s\"", auth_buf);

    switch(cp_cfg[vap].cloud_provider) {
        case CLOUD_PROVIDER_INTERNAL:
            ret = parse_internal_header(conn, do_ssl, vap, node, &timeout);
            break;
        default:	/* Should not come here. */
            ret = FAILURE;
            CP_ERROR (1, "%s: Should not come here.\n",__func__);
            break;
    }
    node->client.session_time.end = (time_t) timeout;
    return ret;
}

int
cp_httpd_event_process (int conn_fd, client_node_t *node, int do_redir, int vap)
{
    int ret = SUCCESS;
    nw_addr_t *client = &node->client.client_addr;
    if (do_redir) {
        ret = cp_redir_main (client, (void *)conn_fd,0, vap);
    } else {
        CP_ERROR(1,"Handle the http event for the logon, conn_fd = %d", conn_fd);
        ret = handle_req ((void *)conn_fd, 0, node, vap);
    }
    shutdown(conn_fd,2);
    close(conn_fd);
    return ret;
}

int
cp_httpsd_event_process (int conn_fd, client_node_t *node, int do_redir, int vap)
{
    struct redir_socket_t socket;
    nw_addr_t *client = &node->client.client_addr;
    int ret = SUCCESS;

    CP_ERROR(1,"Handling HTTPS request for client mac = %s, ip = %s", mactoa(client->mac), inet_ntoa(client->ipv4));

    socket.sslcon = openssl_accept_fd(initssl(), conn_fd, 10, NULL);
    if(socket.sslcon == NULL) {
        CP_ERROR(1,"accpet return shutdown");
        return FAILURE;
    }
    if(do_redir) {
        ret = cp_redir_main(client, (void *)socket.sslcon, 1, vap);
    } else {
        ret = handle_req ((void *)socket.sslcon, 1, node,vap);
    }
    /* shutdown(conn_fd,2); */
    close(conn_fd);
    if (socket.sslcon) {
        openssl_shutdown(socket.sslcon, 2);
        openssl_free(socket.sslcon);
        socket.sslcon = 0;
    }
    return ret;
}

