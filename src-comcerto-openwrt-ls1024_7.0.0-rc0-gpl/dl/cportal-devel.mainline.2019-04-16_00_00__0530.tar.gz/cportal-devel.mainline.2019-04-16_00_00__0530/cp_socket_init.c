#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <linux/types.h>
#include <errno.h>
#include "cp_socket_init.h"
#include "cp_netfilter.h"
#include "cp_dman.h"
#include "ssl.h"

static fds_t gFds[VAP_END];

//int dman_cp_sock_fd;

#ifndef O_NONBLOCK
#define O_NONBLOCK O_NDELAY
#endif

int ndelay_on (int fd) {
    register int got = fcntl(fd, F_GETFL);
    return (got == -1) ? -1 : fcntl(fd, F_SETFL, got | O_NONBLOCK);
}

int ndelay_off (int fd) {
    register int got = fcntl(fd, F_GETFL);
    return (got == -1) ? -1 : fcntl(fd, F_SETFL, got & ~O_NONBLOCK);
}

void close_socket(int fd)
{
    if (fd <= 0) {
        return;
    }
    shutdown(fd, 2);
    close (fd);
}

void close_registered_sockets(vap_if_index_t index)
{
    close_socket(vap[index].queue_fd);
    eloop_unregister_read_sock(vap[index].queue_fd);
    vap[index].queue_fd = 0;

    close_socket(gFds[index].redir_http);
    eloop_unregister_read_sock(gFds[index].redir_http);
    gFds[index].redir_http = 0;

    close_socket(gFds[index].redir_https);
    eloop_unregister_read_sock(gFds[index].redir_https);
    gFds[index].redir_https = 0;

    close_socket(gFds[index].login_http);
    eloop_unregister_read_sock(gFds[index].login_http);
    gFds[index].login_http = 0;

    close_socket(gFds[index].login_https);
    eloop_unregister_read_sock(gFds[index].login_https);
    gFds[index].login_https = 0;
}

int
cp_init_http_socket (unsigned char do_ssl, unsigned char do_redir, vap_if_index_t index)
{
    unsigned short int fd_httpd;
    usockaddr http;
    unsigned short int ret;
    int on = 1;

    int http_port;
    int https_port;

    if (do_redir) {
        http_port = VAP_BASE_HTTP_NFQ_PORT + index;
        https_port = VAP_BASE_HTTPS_NFQ_PORT + index;
    } else {
        http_port = LOGON_BASE_HTTP_PORT + index;
        https_port = LOGON_BASE_HTTPS_PORT + index;
    }

    fd_httpd = socket (AF_INET, SOCK_STREAM, 0);
    if (fd_httpd == FAILURE)
    {
        perror ("socket");
        CP_ERROR (1, "HTTP socket call failed  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return FAILURE;
    }
    else
    {
        CP_INFO (1, "HTTP socket call success  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
    }
    if (setsockopt (fd_httpd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof (on)) < 0)
    {
        perror ("setsockopt");
        CP_ERROR (1, "HTTP setsockopt call failed  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);

        return FAILURE;
    }
    else
    {
        CP_INFO (2, "HTTP setsockopt success  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
    }

    if (do_redir) {
        struct linger linger;

        linger.l_onoff = 1;
        linger.l_linger = 0;

        if (setsockopt (fd_httpd, SOL_SOCKET, SO_LINGER, (void *)&linger, sizeof(linger)) < 0) {
            perror ("setsockopt");
            CP_ERROR (1, "HTTP setsockopt call failed  FILE:%s-FUNCTION:%s-LINE:%d",
                    __FILE__, __func__, __LINE__);
            return FAILURE;
        } else {
            CP_INFO (2, "HTTP setsockopt success  FILE:%s-FUNCTION:%s-LINE:%d",
                    __FILE__, __func__, __LINE__);
        }
    }

    (void) fcntl (fd_httpd, F_SETFD, 1);
    http.sa_in.sin_family = AF_INET;
    http.sa_in.sin_port = htons ( do_ssl ? https_port : http_port );
    if (index != 0 || (https_port == VAP_BASE_HTTPS_NFQ_PORT || http_port == VAP_BASE_HTTPS_NFQ_PORT)) {
	    http.sa_in.sin_addr.s_addr = htonl (INADDR_LOOPBACK);
    } else {
	    http.sa_in.sin_addr.s_addr = htonl (INADDR_ANY);
    }

    ret =
        bind (fd_httpd, (struct sockaddr *) &http,
                sizeof (struct sockaddr_in));
    if (ret == FAILURE)
    {
        perror ("bind");
        CP_ERROR (1, "HTTP bind call failed  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return FAILURE;
    }
    else
    {
        CP_INFO (1, "HTTP bind call success  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
    }
    if (listen (fd_httpd, MAX_LISTEN) < 0)
    {
        perror ("listen");
        CP_ERROR (1, "HTTP listen call failed  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return FAILURE;
    }
    else
    {
        CP_INFO (1, "HTTP listen success  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
    }
    /* register_http_descripter(fd_httpd,do_ssl); */
    eloop_register_read_sock(fd_httpd, cp_handle_request, NULL, (void *)SET_VAP_INSTANCE(index, do_ssl, do_redir));

    if (do_redir) {
        if (do_ssl) {
            gFds[index].redir_https = fd_httpd;
        } else {
            gFds[index].redir_http = fd_httpd;
        }
    } else {
        if (do_ssl) {
            gFds[index].login_https = fd_httpd;
        } else {
            gFds[index].login_http = fd_httpd;
        }
    }
    return SUCCESS;
}

int
cp_init_dns_socket (void)
{
    int sock_id;
    struct sockaddr_in own;
    sock_id=socket(AF_INET,SOCK_DGRAM,0);
    if(sock_id < 0){
        CP_ERROR(1,"DNS socket create failed");
        return FAILURE;
    }
    own.sin_family=AF_INET;
    own.sin_port=htons(CP_DNS_PORT);
    own.sin_addr.s_addr=inet_addr("0.0.0.0");
    if(bind(sock_id,(struct sockaddr *)&own,sizeof(own))< 0){
        CP_ERROR(1,"DNS bind failed");
        return FAILURE;
    }
#ifdef IPPKT_INFO
    int opt = 1; //for IP_PKTINFO: extract dst_addr during recvmsg(), for multihome udp
    int ret = setsockopt(sock_id, SOL_IP, IP_PKTINFO, &opt, sizeof(opt));
    if(ret < 0){
        CP_ERROR(1,"set socket opt in DNS failed");
        return FAILURE;
    }
#endif

    // eloop_register_read_sock (sock_id, cp_dns_event_process, NULL);


    return SUCCESS;
}
#if 0
int
cp_init_dman_socket (void)
{
    int sock_id;
    struct sockaddr_un own;

    sock_id = socket (AF_LOCAL, SOCK_DGRAM, 0);

    if (sock_id < 0)
    {
        perror ("socket");
        CP_ERROR (1, "DMAN socket init failed  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return FAILURE;
    }

    memset (&own, 0, sizeof (own));
    own.sun_family = AF_LOCAL;
    /* own.sun_path[0] = '\0'; */
    snprintf (own.sun_path, sizeof (own.sun_path), CP_DMAN_SOCK);

    if (bind (sock_id, (struct sockaddr *) &own, sizeof (own)) < 0)
    {
        perror (__FILE__ ":bind");
        close (sock_id);
        return FAILURE;
    }

    CP_ERROR (1, "DMAN socket init completed(%d)  FUNCTION:%s-LINE:%d",
            sock_id, __func__, __LINE__);

    eloop_register_read_sock (sock_id, cp_dman_event_process, NULL);
    dman_cp_sock_fd = sock_id;
    return SUCCESS;
}
#endif
int cp_get_port_number(int vap,int do_ssl)
{ 
    if(do_ssl) {
        return VAP_BASE_HTTP_NFQ_PORT+vap;
    }else{
        return VAP_BASE_HTTPS_NFQ_PORT+vap;
    }
}

int my_read(void *conn,int do_ssl, char *buffer, size_t len)
{
    int ret, fd = 0, err = 0, retries = 0;
    openssl_con *sslcon = NULL;

    if(do_ssl){
        sslcon = (openssl_con *) conn;
        ret=openssl_read(sslcon,buffer,len,1);
        if(ret < 1){
            CP_ERROR(1,"SSL read failed, ret = %d", ret);
            return ret;
        }
        buffer[ret] = '\0';
        printf("%s(): ret = %d, SSL buffer - \"%s\"", __func__, ret, buffer);
        return ret;
    } else {
        fd = (int) conn;
        while((retries++) < MAX_RETRY) {
            ret=recv(fd, buffer, len, 0);
            err = errno;
            if (ret < 0) {
                if ((err == EAGAIN) || (err == EWOULDBLOCK)) {
                    printf (".");
                    usleep(1);
                    err = 0;
                } else {
                    printf ("\n");
                    perror("my_read()->recv()");
                    CP_ERROR(1,"HTTP read failed, ret = %d", ret);
                    break;
                }
            } else {
                printf ("\n%s(): read success\n", __func__);
                break;
            }
        }
        if (ret >= 0) {
            if (ret > len) {
                ret = len;
            }
            buffer[ret] = '\0';
        }
        printf("\n%s(): ret = %d, buffer - \"%s\"", __func__, ret, buffer);
        return ret;
    }

}
