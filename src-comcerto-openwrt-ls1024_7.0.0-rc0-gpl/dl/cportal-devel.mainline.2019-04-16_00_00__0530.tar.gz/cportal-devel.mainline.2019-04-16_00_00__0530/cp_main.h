#ifndef _CP_MAIN_H
#define _CP_MAIN_H 1

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include <sys/socket.h>
#include <netinet/tcp.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <linux/types.h>
#include <linux/netfilter.h>	/* for NF_ACCEPT */
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <syslog.h>
#include <signal.h>
#include <sys/un.h>
#include "cp_debug.h"

/*Common Return Value*/
#define SUCCESS 0
#define FAILURE -1

#define AUTH_FAIL 1
#define AUTH_UNKNOWN 0

#define TRUE  1
#define FALSE !TRUE

/*daemon PID file*/
#define CPID_FILE "/var/run/captive.pid"
/*port declaration*/

#define DNS_PORT 1000
#define CP_DMAN_SOCK  "/tmp/cportald_dman_sock"

/*HTTP method*/
#define GETINFO "getinfo"
#define CPORTAL "cportal/" 
#define AUTH_TOKEN "authtoke"
#define LANDING_URL "landing_url"
#define USERNAME "username"
#define LOGIN_PASSWORD "password"
#define CLI_IP "client_ip"
#define CLI_MAC "client_mac"
#define SESSION_TIMEOUT "sessiontimout"
#define SOCIAL_URL "url"
#define TIME_INTERVAL "time-interval"
#define LOGIN "/logon"
#define LOGOFF "/logoff"
#define LOGOUT "/logout"
#define SOCIAL "/social"
#define LOGIN_ERR_CODE 10
#define LOGOUT_CODE 5
#define CPORTAL_INFO 4
#define CPORTAL_CODE 3
#define SOCIAL_CODE 2
#define LOGIN_CODE 1
#define LOGOFF_CODE 0

#define USE_SSL
#define HAVE_SSL 1

#define MAX_VAP_NAME_LEN 11
#define MAX_DOMAIN_NUM   25
#define MAX_DOMAIN_LEN   127

#define REDIR_MAXTIME 120

#define MAX_RETRY 10000

#define MAX_AUTHTOKEN_LEN	50	/* IP=12, MAC=12, worst case auth_len = IP+IP+MAC+MAC=48 */
#define IP_DELIMITER		'.'
#define MAC_DELIMITER		':'

/* These are the names(options) of the 
 * supported clouds for captive-portal.
 * These strings are to be used as it is, 
 * in the commands for setting cloud-provider */
#define CLOUD_NAME_INTERNAL     "internel"

typedef enum {
    CLOUD_PROVIDER_INTERNAL,
    CLOUD_PROVIDER_MAX
} cloud_provider;

typedef enum vap_if_index_e
{
    WL0 = 0,
    WL1,
    WL01,
    WL11,
    WL02,
    WL12,
    WL03,
    WL13,
    VAP_END			/* Should be in the bottom */
} vap_if_index_t;

extern const char gVapWlanMap[VAP_END][MAX_VAP_NAME_LEN];

int _cp_init_socket (int i);
int dns_init (void);

#endif
