#ifndef _CP_NF_RULES_H
#define _CP_NF_RULES_H 1

#include "cp_main.h"

#define CMD_STR_LEN          255
#define CAPTIVE_PORTAL_CHAIN_RULE_LEN 250 
#define CP_NF_RULE_PATH      "/tmp/cp_nf_rules/"
#define CP_NF_RULE_PATH_LEN  sizeof(CP_NF_RULE_PATH)
#define RULES_FILE_NAME_LEN  (MAC_ADDR_STR_LEN + CP_NF_RULE_PATH_LEN + 3)
#define CLIENT_RULES_FILE_NAME_LEN ( MAC_ADDR_STR_LEN + CP_NF_RULE_PATH_LEN + MAX_VAP_NAME_LEN + 8)

#define EBTABLES             0
#define IPTABLES             1
#define IP6TABLES             2
#define EBTABLES_CMD         "/usr/sbin/ebtables --concurrent"
#define IPTABLES_CMD         "/usr/sbin/iptables -w"
#define IP6TABLES_CMD         "/usr/sbin/ip6tables -w"

#define NF_APPEND            1

#define exec_rule(x)         system((x))

#define cp_add_client_rule (cmd, hw_addr, tbl, pos, chain, fmt, args...)  ({ \
        char fname[CLIENT_RULES_FILE_NAME_LEN];			\
        int rc = 0;							\
        snprintf (fname, CLIENT_RULES_FILE_NAME_LEN,		\
            "%s%s", CP_NF_RULE_PATH, mactoa((hw_addr)));	\
        rc = cp_add_rule ((cmd), fname, (tbl), (pos), (chain), fmt, ##args); \
        rc;								\
        })

int cp_add_rule (uint8_t command, char *rules_file_name, const char *table,
        uint8_t insert_pos, char *chain, const char *fmt, ...);
int cp_init_walled_garden_rules (vap_if_index_t if_index);
int cp_update_walled_garden_rules (vap_if_index_t i);
int _cp_init_nf_rules (vap_if_index_t i);
int cp_add_client_bypass_rule (vap_if_index_t if_index, char *mac, int wallg_bypass);
int cp_add_client_route (vap_if_index_t if_index, char *mac, char *ip_addr);
void cp_flush_client_rules (vap_if_index_t if_index, char *mac);
void cp_flush_client_route (vap_if_index_t if_index, char *mac);


#endif
