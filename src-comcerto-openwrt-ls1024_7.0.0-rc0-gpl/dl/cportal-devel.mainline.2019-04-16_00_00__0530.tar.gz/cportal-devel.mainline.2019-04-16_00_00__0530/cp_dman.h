#ifndef _CP_DMAN_H
#define _CP_DMAN_H 1

#include "cp_nf_rules.h"
#include "cp_main.h"
#include "capportald.h"
#define DNS_DMAN_SOCK "/tmp/dns_dman_comm"
typedef enum {
    CP_DMAN_STATUS_NOTIFY = 1,
    CP_DMAN_SPLASH_URL_NOTIFY,
    CP_DMAN_WALLED_GARDEN_NOTIFY,
    CP_DMAN_INACTIVITY_TIMEOUT_NOTIFY,
    CP_DMAN_CLOUD_PROVIDER_NOTIFY
} cmd_type;

typedef struct {
    unsigned char isAdded;
    char domain[MAX_DOMAIN_LEN+1];
    unsigned char isSocial;
} wg_instance_t;

typedef struct {
    cmd_type cmd_id;
    vap_if_index_t if_index;
    union {
        unsigned char status;
        char splash_url[SPLASH_URL_LEN+1];
        wg_instance_t wg;
        int timeout;
        int cloud_provider;
    } u;
} captive_sock_t;

int cp_dman_event_process (int sock, void *eloop_ctx, void *user_data);

#define CP_DMAN_MSG_SIZE_MAX sizeof(captive_sock_t)

#endif
