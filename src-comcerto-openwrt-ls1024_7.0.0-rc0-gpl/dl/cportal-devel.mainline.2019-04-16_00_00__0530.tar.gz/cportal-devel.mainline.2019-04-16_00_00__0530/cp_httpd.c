#include"cp_httpd.h"
#include"cp_debug.h"
#include<errno.h>

int
cp_handle_http_request (int sock,client_node_t *node, unsigned char do_ssl,
        unsigned char do_redir, unsigned char vap)
{
    int ret;
    if(do_ssl) {
        ret = cp_httpsd_event_process (sock, node, do_redir, vap);
    } else {
        ret = cp_httpd_event_process (sock, node, do_redir, vap);
    }
    return ret;
}

int use_select(int fd)
{
    fd_set lfd;
    int max=fd;
    FD_ZERO(&lfd);
    FD_SET(fd,&lfd);
    struct timeval tv;
    tv.tv_usec=100000;
    tv.tv_sec=0;
    int ret;
    ret=select(max+1,&lfd,NULL,NULL,&tv);
    if(ret >= 1){
        return 0;
    }
    else{
        if(ret==0){
            printf("timeout happens\n");
        }
        else{
            printf("select failed\n");
        }
        return -1;
    }
}

