/** @file cportalctl_thread.c
    @brief Monitoring and control of cportal, server part
*/

#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <syslog.h>
#include <signal.h>
#include <errno.h>

#include "cp_debug.h"
#include "capportald.h"
#include "cp_client_list.h"

#define MAX_BUF 4096

/* Defined in clientlist.c */
extern	pthread_mutex_t	client_list_mutex;
extern	pthread_mutex_t	config_mutex;

static void *thread_cportalctl_handler(void *);
static void cportalctl_status(int);
static void cportalctl_status_with_type(int, int);
static void cportalctl_deauth(int, char *);

/** Launches a thread that monitors the control socket for request
@param arg Must contain a pointer to a string containing the Unix domain socket to open
@todo This thread loops infinitely, need a watchdog to verify that it is still running?
*/
void*
thread_cportalctl(void *arg)
{
    int	sock,    fd;
    char	*sock_name;
    struct 	sockaddr_un	sa_un;
    int result;
    pthread_t	tid;
    socklen_t len;

    CP_INFO(1, "Starting cportalctl.");

    memset(&sa_un, 0, sizeof(sa_un));
    sock_name = (char *)arg;
    CP_INFO(1, "Socket name: %s", sock_name);

    if (strlen(sock_name) > (sizeof(sa_un.sun_path) - 1)) {
        /* TODO: Die handler with logging.... */
        CP_ERROR(1, "CPORTALCTL socket name too long");
        exit(1);
    }

    CP_INFO(1, "Creating socket");
    sock = socket(PF_UNIX, SOCK_STREAM, 0);

    CP_INFO(1, "Got server socket %d", sock);

    /* If it exists, delete... Not the cleanest way to deal. */
    unlink(sock_name);

    CP_INFO(1, "Filling sockaddr_un");
    strcpy(sa_un.sun_path, sock_name); /* XXX No size check because we
                                        * check a few lines before. */
    sa_un.sun_family = AF_UNIX;

    CP_INFO(1, "Binding socket (%s) (%d)", sa_un.sun_path,
            strlen(sock_name));

    /* Which to use, AF_UNIX, PF_UNIX, AF_LOCAL, PF_LOCAL? */
    if (bind(sock, (struct sockaddr *)&sa_un, strlen(sock_name)
                + sizeof(sa_un.sun_family))) {
        CP_ERROR(1, "Could not bind control socket: %s",
                strerror(errno));
        pthread_exit(NULL);
    }

    if (listen(sock, 5)) {
        CP_ERROR(1, "Could not listen on control socket: %s",
                strerror(errno));
        pthread_exit(NULL);
    }

    while (1) {
        memset(&sa_un, 0, sizeof(sa_un));
        len = (socklen_t) sizeof(sa_un); /* <<< ADDED BY DPLACKO */
        if ((fd = accept(sock, (struct sockaddr *)&sa_un, &len)) == -1) {
            CP_ERROR(1, "Accept failed on control socket: %s",
                    strerror(errno));
        } else {
            CP_INFO(1, "Accepted connection on cportalctl socket %d (%s)", fd, sa_un.sun_path);
            result = pthread_create(&tid, NULL, &thread_cportalctl_handler, (void *) (size_t) fd);
            if (result != 0) {
                CP_ERROR(1, "FATAL: Failed to create a new thread (cportalctl handler) - exiting");
                shutdown(fd, 2);
                close(fd);
                continue;
            }
            pthread_detach(tid);
        }
    }

    return NULL;
}

static void *
thread_cportalctl_handler(void *arg)
{
    int fd, done, i;
    char request[MAX_BUF];
    ssize_t read_bytes, len;

    CP_INFO(1, "Entering thread_cportalctl_handler....");

    fd = (int) (size_t) arg;

    CP_INFO(1, "Read bytes and stuff from %d", fd);

    /* Init variables */
    read_bytes = 0;
    done = 0;
    memset(request, 0, sizeof(request));

    /* Read.... */
    while (!done && read_bytes < (sizeof(request) - 1)) {
        len = read(fd, request + read_bytes, sizeof(request) - read_bytes);

        /* Have we gotten a command yet? */
        for (i = read_bytes; i < (read_bytes + len); i++) {
            if (request[i] == '\r' || request[i] == '\n') {
                request[i] = '\0';
                done = 1;
            }
        }

        /* Increment position */
        read_bytes += len;
    }

    CP_INFO(1, "cportalctl request received: [%s]", request);

    if (strncmp(request, "status", 6) == 0) {
        cportalctl_status(fd);
    } else if (strncmp(request, "simple", 6) == 0) {
        cportalctl_status_with_type(fd, STATUS_TYPE_SIMPLE);
    } else if (strncmp(request, "complex", 7) == 0) {
        cportalctl_status_with_type(fd, STATUS_TYPE_COMPLEX);
    } else if (strncmp(request, "deauth", 6) == 0) {
        cportalctl_deauth(fd, (request + 7));
    }

    if (!done) {
        CP_ERROR(1, "Invalid cportalctl request.");
        shutdown(fd, 2);
        close(fd);
        pthread_exit(NULL);
    }

    CP_INFO(1, "cportalctl request processed: [%s]", request);

    shutdown(fd, 2);
    close(fd);
    CP_INFO(1, "Exiting thread_cportalctl_handler....");

    return NULL;
}

static void
cportalctl_status(int fd)
{
    cp_client_print_all();
    int len = 0;
    len = strlen(buffer);
    write(fd,buffer,len);
    memset(buffer,0,len);
    return;
}

static void cportalctl_status_with_type(int fd, int status_type)
{
    cp_client_print_all_with_type(status_type);
    int len = 0;
    len = strlen(buffer);
    write(fd,buffer,len);
    memset(buffer,0,len);
    return;
}

static void
cportalctl_deauth(int fd, char *arg)
{
    struct in_addr ip_addr;

    if(!(strcmp(arg, "255.255.255.255"))) {
        deinit_client_list(DISCONNECT);
        write(fd,"Yes",3);
        return;
    }
    if(inet_aton(arg, &ip_addr) == 0) {
        printf("Invalid ipaddress\n");
        return;
    }
    if(cp_client_logoff_by_ip(ip_addr) == SUCCESS) {
        write(fd,"Yes",3);
    } else {
        write(fd, "No", 2);
    }
}
