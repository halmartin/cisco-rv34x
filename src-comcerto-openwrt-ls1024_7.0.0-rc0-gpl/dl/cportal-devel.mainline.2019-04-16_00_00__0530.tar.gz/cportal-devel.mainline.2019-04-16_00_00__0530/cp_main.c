#include "cp_main.h"
#include "capportald.h"
#include "cp_socket_init.h"
#include "cp_dman.h"
#include <sys/ioctl.h>
#include <linux/if_bridge.h>
#include <net/if.h>
#include "cp_client_list.h"
#include "cportalctl_thread.h"
#include <syslog.h>
#include <signal.h>
#include <time.h>
#include <stdlib.h>

#define exe_cmd(x) system((x))
static int start_daemon (void);
static char *username_to_del = NULL;
static int cp_get_ifaceIpMac_addr (char *if_name, nw_addr_t *addr);
static int cp_get_vapSsid_from_wifiConfig (void);
static int cp_get_vapConfig_from_uciFile (int if_index, char *ssid_config_flag);
static void disable_route_localnet(int vap);
static void enable_route_localnet(int vap);
static int cp_init (void);
static void cp_deinit_per_ssid (int vap);
static int cp_init_per_ssid (void);
void cp_deinit (void);
static int update_pid_file (void);
static void handle_sigchld (int sig);
static void cp_register_signal (void);
static int cp_init_socket (void);

const char gVapWlanMap[VAP_END][MAX_VAP_NAME_LEN] = {
    "wl0",
    "wl1",
    "wl0.1",
    "wl1.1",
    "wl0.2",
    "wl1.2",
    "wl0.3",
    "wl1.3",
};

capportald_cfg_t cp_cfg[VAP_END];
capportald_prof_t cp_prof_cfg[VAP_END];

typedef struct do_s {
    unsigned char ssl;
    unsigned char redir;
} do_t;

static const do_t action[3] = {
    {.ssl = 0, .redir = 1}, {.ssl = 1, .redir = 1},
    {.ssl = 1, .redir = 0}
};

int _cp_init_socket (int i)
{
    int ret, j;
    for (j = 0; j < 3; j++) {
        ret = cp_init_http_socket (action[j].ssl, action[j].redir, i);
        if (ret == FAILURE) {
            CP_ERROR (1, "HTTP socket init failed (%d,%d,%d)",
                    action[j].ssl, action[j].redir, i);
            return FAILURE;
        }
    }
}

int cp_deinit_socket ()
{
    int i;
    for (i = 0; i < VAP_END; i++)
    {
        if (cp_cfg[i].enabled == TRUE) {
            close_registered_sockets(i);
        }
    }
}

static int cp_init_socket (void)
{
    int ret = SUCCESS;
    int i, j;

    for (i = 0; i < VAP_END; i++)
    {
        if ( (cp_cfg[i].ssid_enabled == 1) && (cp_cfg[i].enabled == TRUE) ) {
            if (_cp_init_socket(i) == FAILURE) {
                return FAILURE;
            }
            CP_INFO (1, "HTTP(S) sockets init successfull, for %s", gVapWlanMap[i]);
        }
    }

    return SUCCESS;
#if 0
    ret = cp_init_dns_socket ();
    if (ret == FAILURE)
    {
        CP_ERROR (1, "DNS socket failed  FILE:%s-FUNCTION:%s-LINE:%d", __FILE__,
                __func__, __LINE__);
        return FAILURE;
    }
    {
        CP_ERROR (1, "DNS socket init successfull  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
    }
#endif
}

static void __handle_sigusr1(void *eloop_data, void *user_ctx)
{
    int i = 0;
    CP_ERROR(1, "Inside %s", __func__);

    for(i=0; i < VAP_END; i++) {
        if ( (cp_cfg[i].ssid_enabled == 1) && (cp_cfg[i].enabled == TRUE) ) {
            enable_route_localnet(i);
        }
    }
#if 0
    if(cp_update_nf_rules()==FAILURE){
        CP_ERROR(1,"cp update nf rules failed");
    }
    else{
        CP_ERROR(1,"cp update nf rulse success");
    }
#else
    update_allow_rule_client_list_by_ip();
#endif
}

static void handle_sigusr1(int sig)
{
    eloop_register_timeout(0, 0, __handle_sigusr1, NULL, NULL);
    return;
}

static void __handle_sigusr2(void *eloop_data, void *user_ctx)
{
    int i = 0;
    CP_ERROR(1, "Inside %s", __func__);

    if(cp_init_per_ssid()==FAILURE){
        CP_ERROR(1,"cp update failed");
    }
    else{
        for(i=0; i < VAP_END; i++) {
            if ( (cp_cfg[i].ssid_enabled == 1) && (cp_cfg[i].enabled == TRUE) ) {
                enable_route_localnet(i);
            }
        }
        CP_ERROR(1,"cp update success");
    }
}

static void handle_sigusr2(int sig)
{
    eloop_register_timeout(0, 0, __handle_sigusr2, NULL, NULL);
    return;
}


static void __handle_sigterm(void *eloop_data, void *user_ctx)
{
    CP_ERROR(1,"Cleaning up before exit\n");

    cp_deinit();
    remove(CPID_FILE);
    exit (-1);
}

static void handle_sigterm(int sig)
{
    CP_ERROR(1, "Inside %s", __func__);
    eloop_register_timeout(0, 0, __handle_sigterm, NULL, NULL);
    /* Just in case the process doesn't quit */
    //alarm(2);
    return;
}

static void handle_sigquit (int sig)
{
    CP_ERROR (1, "Handling sigquit signal");
    cp_client_print_all ();
}

int cp_client_idle_timeout_output(client_node_t *node)
{
    char idle_time_count_command[100] = {0}, temp[20] = {0};
    int timeout = 0;
    FILE *fp;

    snprintf(idle_time_count_command, sizeof(idle_time_count_command),"wl -i %s sta_info %s | grep idle | awk \'{print $2}\'",node->client.vap_if_name,mactoa(node->client.client_addr.mac));

    fp = popen(idle_time_count_command,"r");
    if ( fp == NULL) {
        CP_ERROR(1, "Error in running %s command",idle_time_count_command);
        return;
    }

    if (fscanf(fp, "%s",temp)) {
        if(0 == strlen(temp)) {
            timeout = -1;
        } else {
            timeout = atoi(temp);
        }
    }

    pclose(fp);
    return timeout;
}

static uint8_t lobby_user_update(client_node_t *node)
{
	char uci_cmd_str[BSIZE] = {'\0'};
    FILE *fp = NULL;
	char lobby_exp_str[20] = {'\0'};
	char temp[BSIZE] = {'\0'};
	char *ptr = NULL;
    int len;
	uint8_t ret = FALSE;

	memset(uci_cmd_str,0,sizeof(uci_cmd_str));
	snprintf(uci_cmd_str, sizeof(uci_cmd_str),"uci show lobby.%s.expirestr",node->client.pam_data.username);
	fp = popen(uci_cmd_str,"r");
	if ( fp == NULL) {
		CP_ERROR(1, "Error in running %s command", uci_cmd_str);
		return FALSE;
	}
	if (fgets(temp, BSIZE, fp) != NULL) {
		if ( 0 == strcmp(temp,"uci: Entry not found")) 
			goto false_out;

		ptr = strstr(temp,"=");
		if ( ptr == NULL ) 
			goto false_out;
		ptr = ptr + 2;//skip =' character

		//format 460616032017====>2017.03.16-06:46
		strncpy(lobby_exp_str+14,ptr,2);//min 2 characters
		lobby_exp_str[13]=':';

		strncpy(lobby_exp_str+11,ptr+2,2);//hour 2 characters
		lobby_exp_str[10]='-';
		strncpy(lobby_exp_str+8,ptr+4,2);//day 2 characters
		lobby_exp_str[7]='.';
		strncpy(lobby_exp_str+5,ptr+6,2);//mon 2 characters
		lobby_exp_str[4]='.';
		strncpy(lobby_exp_str,ptr+8,4);//year 4 characters
		CP_ERROR(1, "%s(%d)type=%d,exp_time=%s\n", __FUNCTION__,__LINE__,node->client.cp_user,lobby_exp_str);
	} else {
		goto false_out;
	}		

	fclose(fp);

	memset(uci_cmd_str,0,sizeof(uci_cmd_str));
	snprintf(uci_cmd_str, sizeof(uci_cmd_str),"date --date=\"%s\" +%%s",lobby_exp_str);
	fp = popen(uci_cmd_str,"r");
	if ( fp == NULL) {
		CP_ERROR(1, "Error in running %s command", uci_cmd_str);
		return FALSE;
	}
	if (fgets(temp, BSIZE, fp) != NULL) {
		node->client.cp_user = LOBBY_USR;
		sscanf(temp,"%lu",&(node->client.lobby_time_exp));
		CP_ERROR(1, "%s(%d)type=%d,exp_time=%s,exp_time_sec=%lu\n", __FUNCTION__,__LINE__,node->client.cp_user,lobby_exp_str,node->client.lobby_time_exp);
		fclose(fp);

        return TRUE;
	} else {
		goto false_out;
	}

false_out:
	fclose(fp);
	return FALSE;
}

static void __handle_sigchld(void *eloop_data, void *user_ctx)
{
    pid_t pid = (pid_t) eloop_data;
    FILE *fptr = NULL;
    char buf[25] = {'\0'};
    char *cmd_str = "cat /tmp/cportal.*";
    char temp[CMD_SIZE] = {'\0'};
    int status, vap, timeout;
    uint32_t ip_addr = 0;
    client_node_t *node = NULL;
    user_cred_t pam_data = {'\0'};

    if(eloop_data == NULL && user_ctx == NULL) {
	   if  (fptr = popen(cmd_str,"r")) {
		   while(fscanf(fptr,"%d,%d,%x,%d,%s", &status, &vap, &ip_addr,&timeout, pam_data.username) && !feof(fptr)) {
			   node = (client_node_t *) cp_client_present_ip_check(ip_addr,vap);
			   /* If lobby account time is updated, re-schedule the timer for conneceted clients */
			   if (status == AUTHENTICATED && is_lobby_user(pam_data.username) && node) {
					   cp_client_update_username(node, &pam_data);
					   cp_client_state_change_without_search(node, AUTHENTICATED);
					   lobby_user_update(node);
					   CP_ERROR(1, "%s(%d)Client ip_addr=%s (%s) on SSID \"%s\" lobby_time_exp=%lu\n",__FUNCTION__,__LINE__,inet_ntoa(node->client.client_addr.ipv4), mactoa(node->client.client_addr.mac),cp_cfg[vap].wki.ssid,node->client.lobby_time_exp);
					   cp_cancel_inactivity_timer(ip_addr,vap);
					   cp_schedule_inactivity_timer( ip_addr, vap, (node->client.lobby_time_exp - time(NULL)));
                            cp_syslog(LOG_NOTICE, "Client %s (%s) on SSID \"%s\" (%s) has been sucessfully AUTHENTICATED, with timeout = %d",inet_ntoa(node->client.client_addr.ipv4), mactoa(node->client.client_addr.mac),cp_cfg[vap].wki.ssid, gVapWlanMap[vap], (node->client.lobby_time_exp - time(NULL)));
			    /* If lobby account is deleted, make timeout as 0 and terminate the connected clients from CP authenticated list*/
			   } else if (status == AUTHENTICATED && node && node->client.cp_user == LOBBY_USR) {
				   cp_cancel_inactivity_timer(ip_addr,vap);
				   node->client.lobby_time_exp = 0;
				   cp_schedule_inactivity_timer(ip_addr,vap,0);
				   cp_syslog(LOG_NOTICE,"Client ip_addr=%s connected to lobby account but lobby account is expire or deleted\n",inet_ntoa(node->client.client_addr.ipv4));
			   }
		   }
		   fclose(fptr);
	   } else {
		   return;
	   }
    } else { 
    sprintf(buf, "/tmp/cportal.%d", pid);
    if((fptr = fopen(buf, "r")) != NULL){
        fscanf(fptr, "%d,%d,%x,%d,%s", &status, &vap, &ip_addr,
                &timeout, pam_data.username);
        switch(status) {
#if 0
            case AUTHORIZED:
                {
                    node = (client_node_t *) cp_client_present_ip_check(ip_addr,vap);
                    if (node) {
                        cp_client_state_change_without_search(node,AUTHORIZED);
                        cp_schedule_session_timer(ip_addr, vap, timeout);
                        CP_ERROR(1, "*************SOCIAL LOGIN************\n");
                        //cp_syslog(LOG_NOTICE, "Client %s (%s) on SSID \"%s\" (%s) has been authorized for SOCIAL LOGIN, with timeout = %d",
                        //inet_ntoa(node->client.client_addr.ipv4), mactoa(node->client.client_addr.mac),
                        //cp_cfg[vap].wki.ssid, gVapWlanMap[vap], timeout);
                    }
                }
                break;
#endif
            case LOGGED_OFF:
                {
                    cp_client_state_change_with_ip (ip_addr, UNAUTHENTICATED, vap);
                }
                break;
            case AUTHENTICATED:
                {
                    node = (client_node_t *) cp_client_present_ip_check(ip_addr,vap);
                    if (node) {
                        if(node->client.state.current == AUTHORIZED)
                        {
                        }
                        //if (cp_cfg[vap].auth) {
                        cp_client_update_username(node, &pam_data);
                        //}
                        cp_client_state_change_without_search(node, AUTHENTICATED);
                        if (is_lobby_user(node->client.pam_data.username) == TRUE) {
                            lobby_user_update(node);
                            CP_ERROR(1, "%s(%d)Client ip_addr=%s (%s) on SSID \"%s\" lobby_time_exp=%lu\n",__FUNCTION__,__LINE__,inet_ntoa(node->client.client_addr.ipv4), mactoa(node->client.client_addr.mac),
                                    cp_cfg[vap].wki.ssid,node->client.lobby_time_exp);
                            cp_schedule_inactivity_timer( ip_addr, vap, (node->client.lobby_time_exp - time(NULL)));
                            cp_syslog(LOG_NOTICE, "Client %s (%s) on SSID \"%s\" (%s) has been sucessfully AUTHENTICATED, with timeout = %d",
                                    inet_ntoa(node->client.client_addr.ipv4), mactoa(node->client.client_addr.mac),
                                    cp_cfg[vap].wki.ssid, gVapWlanMap[vap], (node->client.lobby_time_exp - time(NULL)));
                        } else {
				/* Update proper flag if lobby user disconnected and try to connect with general CP account */
				node->client.cp_user =GENERAL_USR;
                            cp_schedule_inactivity_timer( ip_addr, vap, cp_cfg[vap].timeout);
                            cp_syslog(LOG_NOTICE, "Client %s (%s) on SSID \"%s\" (%s) has been sucessfully AUTHENTICATED, with timeout = %d",
                                    inet_ntoa(node->client.client_addr.ipv4), mactoa(node->client.client_addr.mac),
                                    cp_cfg[vap].wki.ssid, gVapWlanMap[vap], cp_cfg[vap].timeout);
                        }
                    }
                }
                break;
        }
        fclose(fptr);
	/* Delete CP pid file only for general CP user */
	if (status != AUTHENTICATED || node->client.cp_user !=LOBBY_USR)
        remove(buf);
    }
    }
}

static void handle_sigchld (int sig)
{
    pid_t pid;
    int status;
    while ((pid = waitpid (-1, &status, WNOHANG)) > 0) {
        if (WIFEXITED(status) == TRUE) {
            switch(WEXITSTATUS(status)) {
                case AUTHORIZED:
                case LOGGED_OFF:
                case AUTHENTICATED:
                    eloop_register_timeout(0, 0, __handle_sigchld, (void *)pid, NULL);
                    break;
                default:
                    break;
            }
        }
    }
}
/* This function will delete the lobby account when work hour expires */
void lobby_user_del_alarm_ring(int sig) {
	char cmd[BSIZE] = {'\0'};
	int ret = 0;
	/* Delete user account using confd_cmd */
	snprintf(cmd,sizeof(cmd),"confd_cmd -c \"mdel /cp-users/cp-user\{%s\}\"",username_to_del);
	if (username_to_del) {
		free(username_to_del);
		username_to_del = NULL;
	}
	ret = exe_cmd(cmd);
	if (ret == -1) {
		CP_ERROR(1,"Error in running %s command",cmd);
	}
}

void  lobby_user_acc_alarm_update (int sig) {
	char uci_cmd_str[BSIZE] = {'\0'};
	FILE *fp = NULL, *fp2 = NULL;
	char *next_username = NULL, *old_username = NULL, *temp_username = NULL;
	unsigned long int exp_time_sec = 0, less_exp_time = 0;
	char lobby_exp_str[20] = {'\0'};
	char temp[BSIZE] = {'\0'};
	char *ptr = NULL;
	int len = 0, tea_flag = 0, num_of_lobby_acc = 0;

	/* Get lobby configuration & read username */
	memset(uci_cmd_str, 0, sizeof(uci_cmd_str));
	snprintf(uci_cmd_str, sizeof(uci_cmd_str),"uci show lobby");
	fp = popen(uci_cmd_str,"r");
	if ( fp == NULL) {
		CP_ERROR(1, "Error in running %s command", uci_cmd_str);
		return;
	}
	while(fgets(temp,BSIZE,fp) != NULL) {
		if (ptr = strstr(temp,"username=")) {
			num_of_lobby_acc++;
			ptr = ptr + 9;
			len = strlen(ptr);
			temp_username = (char *)calloc(1,len);
			strncpy(temp_username,ptr,len);
			temp_username[--len] = 0; /* Ignore null in username string */
			
			/* Read tea value which denotes delete account checkbox status */
			memset(uci_cmd_str,0,sizeof(uci_cmd_str));
			sprintf(uci_cmd_str,"uci show lobby.%s.tea",temp_username);
			fp2 = popen(uci_cmd_str, "r");
			if (fp2 == NULL) {
				CP_ERROR(1,"Error in running %s command",uci_cmd_str);
				return;
			}
			if (fgets(temp, BSIZE, fp2) != NULL) {
				if (ptr = strstr(temp,"tea='")) {
					ptr = ptr + 5;
				}
				fclose(fp2);
				/* Pass if user account is marked with delete account at the end of work hour */
				if (*ptr == '1') {
					tea_flag++;

					if (!old_username) {				/* Store current username in oldusername for 1st lobby user */
						old_username = temp_username;
					} else if (!next_username) {			/* Store current username in next_username for 2nd lobby user */
						next_username = temp_username;
					} else if (less_exp_time == exp_time_sec) {	/* Swap username which has less exp time */
						free(old_username);
						old_username = next_username;
						next_username = temp_username;
					} else if (less_exp_time < exp_time_sec) {	/* Overwrite nextusername with temp_username which has less exp time*/
						free(next_username);
						next_username = temp_username;
					}
					/* Read Expiration seconds for lobby user */	
					memset(uci_cmd_str,0,sizeof(uci_cmd_str));
					sprintf(uci_cmd_str,"uci show lobby.%s.expirestr",temp_username);
					fp2 = popen(uci_cmd_str,"r");
					if (fp2 == NULL) {
						CP_ERROR(1,"Error in runnig command\n");
						return;
					}
					/* Timer caluculation */
					if (fgets (temp, BSIZE, fp2) != NULL) {
						if (ptr = strstr(temp,"expirestr='")){
							ptr = ptr + 11;
							fclose(fp2);
							/* format 460616032017====>2017-03-16 06:46 */
							strncpy(lobby_exp_str+14,ptr,2);//min 2 characters
							lobby_exp_str[13]=':';
							strncpy(lobby_exp_str+11,ptr+2,2);//hour 2 characters
							lobby_exp_str[10]=' ';
							strncpy(lobby_exp_str+8,ptr+4,2);//day 2 characters
							lobby_exp_str[7]='-';
							strncpy(lobby_exp_str+5,ptr+6,2);//mon 2 characters
							lobby_exp_str[4]='-';
							strncpy(lobby_exp_str,ptr+8,4);//year 4 characters
							/* Convert expiration time string to no of seconds */
							memset(uci_cmd_str,0,sizeof(uci_cmd_str));
							snprintf(uci_cmd_str, sizeof(uci_cmd_str),"date --date=\"%s\" +%%s",lobby_exp_str);
							fp2 = popen(uci_cmd_str,"r");
							if ( fp2 == NULL) {
								CP_ERROR(1, "Error in running %s command", uci_cmd_str);
								return;
							}
							if (fgets(temp, BSIZE, fp2) != NULL) {
								sscanf(temp,"%lu",&exp_time_sec); /* Storing expiration time in seconds */
								if (less_exp_time == 0 || less_exp_time >= exp_time_sec) { /* Lesser time updation */
									less_exp_time = exp_time_sec;
								} 
							}
							fclose(fp2);
						}
					}
				} else {
					free(temp_username);
				}
			}
		}
	}
	fclose(fp);
	/* Update username_to_delete when time expires */
	if (old_username && !next_username && less_exp_time > (unsigned long int)time(NULL)) {
		username_to_del = old_username;
	} else if (old_username && next_username) {
		if (less_exp_time == exp_time_sec) {
			free(old_username);
			username_to_del = next_username;
		} else {
			free(next_username);
			username_to_del = old_username;
		}
	}
	/* Triggering alarm signal for the user account when time expires */
	if (less_exp_time && less_exp_time > (unsigned long int )time(NULL)) {
		alarm(less_exp_time - (unsigned long int)time(NULL));
		syslog(LOG_INFO,"cportald : alarm updated successfully for lobby account %s\n",username_to_del);
	} else if (less_exp_time && less_exp_time <= (unsigned long int )time(NULL) && tea_flag) {
		if (old_username && !next_username) {
			username_to_del = old_username;
		}
		lobby_user_del_alarm_ring(SIGALRM);
	}
	/* Stop alarm if tea checkbox is disabled after alarm triggered */
	if (!tea_flag) {
		if (num_of_lobby_acc && username_to_del) {
			free(username_to_del);
			username_to_del = NULL;
		}
		alarm(0);
		syslog(LOG_INFO,"cportald : alarm killed successfully\n");
	}
	/* Calling handler to update termination duration for lobby user if time is updated from UI*/
	 __handle_sigchld(NULL,NULL);
}

static void cp_register_signal (void)
{
    eloop_register_signal (SIGCHLD, handle_sigchld, NULL);
    eloop_register_signal (SIGQUIT, handle_sigquit, NULL);
    eloop_register_signal (SIGUSR1, handle_sigusr1, NULL);
    eloop_register_signal (SIGUSR2, handle_sigusr2, NULL);
    eloop_register_signal (SIGTERM, handle_sigterm, NULL);
    eloop_register_signal (SIGINT, handle_sigterm, NULL);
    signal(SIGCONT,lobby_user_acc_alarm_update);
    signal(SIGALRM,lobby_user_del_alarm_ring);
    return;
}

static int update_pid_file (void)
{
    FILE *fp;
    fp = fopen (CPID_FILE, "w");
    if (fp)
    {
        fprintf (fp, "%d\n", getpid ());
        fclose (fp);
        return SUCCESS;
    }
    return FAILURE;
}

int main (int argc, char **argv)
{
    FILE *prev_pid_file = NULL;

    if (cp_log_file_init () == FAILURE)
    {
        printf ("Logging failed \n");
        exit (0);
    }

    CP_INFO (1, "Starting Captive portal service, supports Lobby Ambassador");

    /* Open connection with logger (syslogd) */
    //openlog("captive-portal", LOG_NDELAY, LOG_USER);

    prev_pid_file = fopen(CPID_FILE, "r");
    if (prev_pid_file) {
        int prev_pid = 0;
        fscanf(prev_pid_file, "%d", &prev_pid);
        fclose(prev_pid_file);
        remove(CPID_FILE);
        if (prev_pid > 0) {
            CP_ERROR(1, "Un-clean exit (pid = %d), cleaning up...", prev_pid);
            kill (prev_pid, SIGKILL);
            cp_deinit();
        }
    }
    if (start_daemon () == FAILURE)
    {
        CP_ERROR (1, "Daemon failed");
        return 1;
    }
}

static int start_daemon (void)
{
    pthread_t thread_id;
    int result = 0;

    CP_INFO (1, "Starting captive portal initialization in function: %s",
            __func__);
    if (cp_init () == FAILURE)
    {
        CP_ERROR (1, "Captive Portal Initalization failed");
        remove(CPID_FILE);
        return FAILURE;
    }
    CP_ERROR (2, "Captive-portal initialization successful");
#if DAEMON
    if (daemon (1, 1))
    {
        CP_ERROR (2, "daemon() failed!");
    }
    else
    {
        CP_ERROR (1, "Starting captive Portal Daemon");
    }
#endif
    result = pthread_create(&thread_id, NULL, thread_cportalctl, "/tmp/cportalctl.sock");
    if (result != 0) {
        CP_ERROR(1,"Failed to create thread_cportalctl...\n");
    }

    CP_INFO (1, "Starting ellop run");
    eloop_run ();

    /*This stage never reach*/
    CP_ERROR (1, "Captive Portal Daemon failed");
    /*Deallocate the resource*/
    cp_deinit ();
    CP_ERROR (1, "Captive Portal deinitialization Completed");
}

static void cp_cfg_init(void)
{
    vap_if_index_t i = 0;
    int res = 0;
    char ssid_config_flag[VAP_END] = {0};

    CP_ERROR(1,"cp-captiveportal INIT End\n");

    if (cp_init_profile()) {
        CP_ERROR (2, "Client db config failed FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
    }

    if (cp_get_vapSsid_from_wifiConfig ()) {
        CP_ERROR (2, "Vap ssid config failed FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
    }

    for(i = 0; i < VAP_END; i++) {

        res = cp_get_vapConfig_from_uciFile (i,ssid_config_flag);
        if ( res == FAILURE ) {
            CP_ERROR (2, "Vap config failed FILE:%s-FUNCTION:%s-LINE:%d",
                    __FILE__, __func__, __LINE__);
        } else if ( res == 1) {
            break;
        }
    }

    for(i = 0; i < VAP_END; i++) {
        if ((ssid_config_flag[i] == 0) && (cp_cfg[i].ssid_enabled == 1)) {
            // This vap is not configed, this vap is not in uci show wireless, user may delete it from GUI
            //ssid change from enable to disable,need deinit the clients
            disable_route_localnet(i);
            cp_cfg[i].update_flag = 0x02;
            cp_cfg[i].ssid_enabled = 0;
            cp_cfg[i].enabled = 0;
        }
    }

    /* Just for printing */
    for(i=0; i < VAP_END; i++) {
        CP_ERROR(1,"\n-----------------%s ssid:%s ssid_enabled:%d--------------------\n",gVapWlanMap[i],cp_cfg[i].wki.ssid,cp_cfg[i].ssid_enabled);
        CP_ERROR(1,"%d %s %d",cp_cfg[i].enabled,cp_cfg[i].splash_url,cp_cfg[i].timeout);
    }
}

static const char *CAPTIVE_PORTAL_DNSD = "/usr/sbin/dns";
int dns_init (void)
{
    const char** argv = malloc((sizeof(char*) << 1));
    int ret = 0;
    if (argv == NULL)
    {
        CP_ERROR(1, "%s: malloc() error", __func__);
    }
    else
    {
        argv[0] = CAPTIVE_PORTAL_DNSD;
        argv[1] = NULL;
        if (fork() == 0) {
            ret = execvp(argv[0], (char *const *)argv);
            exit (127);
        }
        free(argv);
    }
    return 0;
}

static int cp_init (void)
{
    int i = 0;

    CP_ERROR (1, "Entering into the function : %s\n", __func__);

    eloop_init (NULL);
    CP_INFO (1, "elopp init Completed FILE:%s-FUNCTION:%s-LINE:%d", __FILE__,
            __func__, __LINE__);
    cp_register_signal ();
    CP_INFO (2, "Signal registration completed FILE:%s-FUNCTION:%s-LINE:%d",
            __FILE__, __func__, __LINE__);

    if (update_pid_file () == FAILURE)
    {
        CP_ERROR (1,
                "Unable to generate the PID file  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
    }
    else
    {
        CP_INFO (2, "PID file generated  FILE:%s-FUNCTION:%s-LINE:%d", __FILE__,
                __func__, __LINE__);
    }

#if 0
    if (cp_init_dman_socket() == FAILURE)
    {
        CP_ERROR (1, "dman socket init failed ");
        return FAILURE;
    }
    CP_ERROR (1, "dman socket init success");
#endif

    cp_cfg_init();

    for(i=0; i < VAP_END; i++) {
        if ( (cp_cfg[i].ssid_enabled == 1) && (cp_cfg[i].enabled == TRUE) ) {
            enable_route_localnet(i);
        }
    }
    if (cp_client_list_init () == FAILURE)
    {
        CP_ERROR (2, "Client list init failed  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
    }
    else
    {
        CP_INFO (1, "Client list init done   FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
    }

    if (cp_init_socket () == FAILURE)
    {
        CP_ERROR (2,
                "socket Initialization failed  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return FAILURE;
    }
    else
    {
        CP_INFO (1, "socket init successfull  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
    }

    if (cp_init_nf_rules () == FAILURE)
    {
        CP_ERROR (1, "Unable to init NF rules");
        return FAILURE;
    }
    else
    {
        CP_ERROR (1, "NF rules init successfull");
    }

    return SUCCESS;
}

static void disable_route_localnet(int vap)
{
    int vap_index=0;
    int disable_flag = 1;
    char cmd[100]={0x0};

    for (vap_index = 0; vap_index < VAP_END; vap_index++)
    {
        if(strcmp( cp_cfg[vap].wki.ssid,cp_cfg[vap_index].wki.ssid) == 0 )
            continue;
        if( (cp_cfg[vap_index].enabled == FALSE) || (cp_cfg[vap_index].ssid_enabled == 0) ) {
            continue;
        }
        if ( strcmp(cp_cfg[vap].wki.br_name,cp_cfg[vap_index].wki.br_name) == 0 ) {
            disable_flag = 0;
            break;
        }
    }
    if( disable_flag  == 1 ) {
        memset(cmd,0,sizeof(cmd));
        sprintf(cmd,"/proc/sys/net/ipv4/conf/%s/route_localnet",cp_cfg[vap].wki.br_name);
        if (file_exist (cmd)) {
            memset(cmd,0,sizeof(cmd));
            sprintf(cmd,"echo 0 >/proc/sys/net/ipv4/conf/%s/route_localnet",cp_cfg[vap].wki.br_name);
            system(cmd);
        } else {
            CP_ERROR (1, "%s(%d)File doesn't exist, filepath=%s\n",__FUNCTION__,__LINE__,cmd);
        }
    }

    return ;
}

static void enable_route_localnet(int vap)
{
    char cmd[100]={0x0};
    FILE *fp;
    int route_localnet = 0;

    sprintf(cmd,"/proc/sys/net/ipv4/conf/%s/route_localnet",cp_cfg[vap].wki.br_name);
    if (file_exist (cmd)) {
        memset(cmd,0,sizeof(cmd));
        sprintf(cmd,"cat /proc/sys/net/ipv4/conf/%s/route_localnet",cp_cfg[vap].wki.br_name);
        if((fp = popen(cmd, "r")) != NULL){
            fscanf(fp, "%d", &route_localnet);
            fclose(fp);
        }

        if ( route_localnet == 0 ) {
            memset(cmd,0,sizeof(cmd));
            sprintf(cmd,"echo 1 >/proc/sys/net/ipv4/conf/%s/route_localnet",cp_cfg[vap].wki.br_name);
            system(cmd);
        }
    } else {
        CP_ERROR (1, "%s(%d)File doesn't exist, filepath=%s\n",__FUNCTION__,__LINE__,cmd);
    }
    return;

}

    static void
cp_deinit_per_ssid (int vap)
{
    destroy_client_list(SSID_CONF_CHANGE,vap);
    cp_flush_vap_rules(vap);
    close_registered_sockets(vap);

    return;
}

static int cp_init_per_ssid (void)
{
    int vap_index=0;
    int cp_en_sum=0;
    int ssid_en_sum=0;

    cp_cfg_init();

    for (vap_index = 0; vap_index < VAP_END; vap_index++) {
        ssid_en_sum = cp_cfg[vap_index].ssid_enabled|ssid_en_sum;
        cp_en_sum = cp_cfg[vap_index].enabled|cp_en_sum;

        if( (cp_cfg[vap_index].update_flag) ) {
            if( (cp_cfg[vap_index].update_flag == 0x02) ) {
                cp_deinit_per_ssid(vap_index);
            }
            if ( (cp_cfg[vap_index].ssid_enabled == 1) && (cp_cfg[vap_index].enabled == TRUE) ){
                enable_route_localnet(vap_index);
                _cp_client_list_init(vap_index);
                _cp_init_socket(vap_index);
                _cp_init_nf_rules(vap_index);
            }
        }
    }

    if( (cp_en_sum == FALSE) || (ssid_en_sum == FALSE) ) {
        cp_deinit();
        remove(CPID_FILE);
        exit (-1);
    }

    return 0;
}


void cp_deinit (void)
{
    deinit_client_list(SSID_CONF_CHANGE);
    cp_deinit_rules();
    cp_deinit_socket();
    //close(dman_cp_sock_fd);
    //remove (CP_DMAN_SOCK);
    //remove(DNS_DMAN_SOCK);
    return;
}

static void cp_copy_prof_cfg(int prof_index, int vap)
{
    char *splash_url;
    int len = -1;

    cp_cfg[vap].auth = cp_prof_cfg[prof_index].cp_cfg.auth;
    cp_cfg[vap].timeout = cp_prof_cfg[prof_index].cp_cfg.timeout;
    cp_cfg[vap].cloud_provider = CLOUD_PROVIDER_INTERNAL;

    len = asprintf(&splash_url, "https://%s:%d/cportal/%s/login.html",
            (inet_ntoa(cp_cfg[vap].wki.ap_addr.ipv4)),
            LOGON_BASE_HTTPS_PORT,
            cp_prof_cfg[prof_index].profile_name );

    strcpy(cp_cfg[vap].captive_profile_name, cp_prof_cfg[prof_index].profile_name);

    if (len < 0) {
        CP_ERROR (1, "Splash url asprintf failed in the function  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return;
    }
    splash_url[len] = '\0';
    strcpy(cp_cfg[vap].splash_url, splash_url);
    free(splash_url);

    len = asprintf(&splash_url, "https://%s:%d/cportal/%s/guest_info.html",
            (inet_ntoa(cp_cfg[vap].wki.ap_addr.ipv4)),
            LOGON_BASE_HTTPS_PORT,
            cp_prof_cfg[prof_index].profile_name );
    splash_url[len] = '\0';
    strcpy(cp_cfg[vap].info_url, splash_url);
    free(splash_url);


    memcpy(&(cp_cfg[vap].redir_url), &(cp_prof_cfg[prof_index].cp_cfg.redir_url), sizeof(cp_cfg[vap].redir_url));


}

static int cp_get_ifaceIpMac_addr (char *if_name, nw_addr_t *addr)
{
    int sock_fd = 0;
    struct ifreq ifr = {'\0'};

    sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock_fd == -1) {
        CP_ERROR(1, "Failed to open socket to get bridge info at FILE:%s-FUNCTION:%s-LINE:%s\n",
                __FILE__, __func__, __LINE__);
        return FAILURE;
    }

    ifr.ifr_addr.sa_family = AF_INET;
    strncpy(ifr.ifr_name, if_name, IFNAMSIZ - 1);

    /* get the interface flags */
    ioctl(sock_fd, SIOCGIFFLAGS, &ifr);
    if (ifr.ifr_flags & IFF_UP) { /* if bridge is up */
        unsigned char *mac;

        /* get the bridge IP addr */
        ioctl(sock_fd, SIOCGIFADDR, &ifr);
        addr->ipv4.s_addr = ((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr.s_addr;

        /* get the bridge MAC addr */
        ioctl(sock_fd, SIOCGIFHWADDR, &ifr);
        mac = (unsigned char *)&ifr.ifr_hwaddr.sa_data[0];
        if (safe_memcpy (addr->mac, mac, MAC_ADDR_LEN) == FAILURE) {
            CP_ERROR (1,
                    "Memory copy failed in the function  FILE:%s-FUNCTION:%s-LINE:%d",
                    __FILE__, __func__, __LINE__);
            close(sock_fd);
            return FAILURE;
        }
    }
    close(sock_fd);

    return SUCCESS;

}

static int cp_get_vapSsid_from_wifiConfig (void)
{
    char uci_cmd_str[CMD_SIZE] = {'\0'};
    char temp[SIZE] = {'\0'};
    char ssid_tmp[SSID_STR_LEN+1] = {'\0'};
    char str[50] = {'\0'};
    FILE *fp = NULL;
    char *ptr,*qtr;
    int i;


    for(i=0; i<VAP_END; i++) {

        cp_cfg[i].update_flag = 0;

        snprintf(uci_cmd_str, sizeof(uci_cmd_str),"wl -i %s ssid | sed 's/^Current SSID: //' | awk '{print substr($0, 2, length($0) - 2)}' | sed 's/\\\\\\\\/\\\\/g'",gVapWlanMap[i]);
        fp = popen(uci_cmd_str,"r");
        if ( fp == NULL) {
            strcpy(cp_cfg[i].wki.ssid,"");
            CP_ERROR(1, "Error in running %s command", uci_cmd_str);
            continue;
        }
        memset(ssid_tmp,0,sizeof(ssid_tmp));

        if (fgets(ssid_tmp, SIZE, fp) != NULL) {
            //format as Current SSID: "ciscosb1"
	    ptr = ssid_tmp;
	    ptr[strlen(ptr) - 1 ] = 0; //Avoid new line at the end
	    if( *ptr == 0 ) { // If ssid is not configured
		    strcpy(cp_cfg[i].wki.ssid,"");
		    continue;
		}
            if( strcmp(ptr,cp_cfg[i].wki.ssid) ) {
                strcpy(cp_cfg[i].wki.ssid,ptr);
                cp_cfg[i].update_flag = 0x01; //ssid changes, clear client table
            }
        } else {
            strcpy(cp_cfg[i].wki.ssid,"");
        }
        pclose(fp);
    }

    return SUCCESS;
}

static int cp_get_vapConfig_from_uciFile (int if_index, char *ssid_config_flag)
{
    char uci_cmd_str[50] = {'\0'};
    char temp[SIZE] = {'\0'};
    char str[50] = {'\0'};
    FILE *fp = NULL;
    char br_name_temp[IFNAMSIZ] = {'\0'};
    char *ptr;
    int prof_index;
    int vlan_id, ret,len;
    int i, cp_en, vap, is_wl1 = -1;
    int ssid_en = 1; //default, ssid is enabled, it will set to 0 when disabled=1

    snprintf(uci_cmd_str, sizeof(uci_cmd_str),"uci show wireless.@wifi-iface[%d] 2>&1", if_index);

    fp = popen(uci_cmd_str,"r");
    if ( fp == NULL) {
        CP_ERROR(1, "Error in running %s command", uci_cmd_str);
        return FAILURE;
    }

    while (fgets(temp, SIZE, fp) != NULL) {
        memset(str,0,sizeof(50));

        if ( (ptr = strstr(temp,"uci: Entry not found")) ) {
            return 1; // 1 means the uci is at the end
        } else if ( (ptr= strstr(temp, "disabled=")) ) { /* get interface status */
            sscanf(ptr+9, "%s", str);
            if (atoi(str) == 1) {
                ssid_en = 0;
            }
        } else if ((ptr = strstr(temp, "device=")) ) {
            sscanf(ptr+7,"%s", str);
            if( (0 == strcmp(str,"wl0")) ) {
                is_wl1=0;
            } else if( (0 == strcmp(str,"wl1")) ) {
                is_wl1=1;
            }
        } else if ( (ptr = strstr(temp, "ssid=")) ) { /* get device ssid */
            //sscanf(ptr+5,"%s", str);
            ptr = ptr+5;
            len = strlen(ptr);
            len = len - 1;
            strncpy(str,ptr,len);
            for (i = 0; i < VAP_END; i++) {
                if ( !(strcmp(cp_cfg[i].wki.ssid, str)) ) {
                    if ( (is_wl1 == 0) && (1 == (i%2)) ) {
                        continue;
                    } else if ( (is_wl1 == 1) && (0 == (i%2)) ) {
                        continue;
                    } else {
                        vap=i;
                        ssid_config_flag[vap] = 1;
                        if( ssid_en == 0 ) {
                            if ( (cp_cfg[vap].ssid_enabled == 1) && (cp_cfg[vap].enabled == TRUE) ) {
                                //ssid change from enable to disable,need deinit the clients
                                disable_route_localnet(vap);
                                cp_cfg[vap].update_flag = 0x02;
                            }
                            cp_cfg[vap].ssid_enabled = ssid_en;
                            goto outside_loop;
                        }
                        if ( cp_cfg[vap].ssid_enabled == 0 ){
                            cp_cfg[vap].update_flag = 0x01;
                        }
                        cp_cfg[vap].ssid_enabled = ssid_en;
                    }
                    break;
                } else {
                    vap = -1;
                }
            }
            if(vap == -1) {
                break;
            }
        } else if ((ptr = strstr(temp, "vlanid=")) ) {
            sscanf(ptr+7,"%s", str);
            vlan_id = atoi(str);

            ret = sprintf(br_name_temp, "br-vlan%d", vlan_id);
            br_name_temp[ret] = '\0';
            if( strcmp(br_name_temp,cp_cfg[vap].wki.br_name) ) {
                if( strlen(cp_cfg[vap].wki.br_name) > 0 )
                    disable_route_localnet(vap);
                strcpy(cp_cfg[vap].wki.br_name,br_name_temp);
                //enable_route_localnet(vap);
                cp_cfg[vap].update_flag = 0x01;
            }

            if (cp_get_ifaceIpMac_addr (cp_cfg[vap].wki.br_name, &(cp_cfg[vap].wki.ap_addr)) == FAILURE) {
                CP_ERROR(1, "Not able to get Bridge IP and MAC at func %s LINE %d\n",
                        __func__, __LINE__);
            }
        } else if ((ptr = strstr(temp, "captive=")) ) {
            sscanf(ptr+8,"%s", str);
            cp_en = atoi(str);
            if( (1 == cp_cfg[vap].enabled) && (0 == cp_en) ) {
                //disable cp, need deinit the clients
                disable_route_localnet(vap);
                cp_cfg[vap].update_flag = 0x02;
            } else if( (0 == cp_cfg[vap].enabled) && (1 == cp_en) ) {
                //enable cp, no need deinit the clients
                cp_cfg[vap].update_flag = 0x03;
            } else if( (1 == cp_cfg[vap].enabled) && (0x01 == cp_cfg[vap].update_flag) ) {
                //ssid changes, and cp is enabled at first, need deinit the clients
                cp_cfg[vap].update_flag = 0x02;
            }

            cp_cfg[vap].enabled = cp_en;
        } else if ((ptr = strstr(temp, "captive_portal_profile=")) ) {
            sscanf(ptr+23,"%s", str);

            for (prof_index = 0; prof_index < VAP_END; prof_index++) {
                if ( !strncmp(cp_prof_cfg[prof_index].profile_name, str, strlen(str))) {
                    cp_copy_prof_cfg(prof_index,vap );
                    break;
                }
            }
        }
    }
outside_loop:

    pclose(fp);

    return SUCCESS;
}
