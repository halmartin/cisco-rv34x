#include <stdbool.h>
#ifndef __CAPTIVE_AUTH_H__
#define __CAPTIVE_AUTH_H__

bool authenticate(char *service, char *user, char *password, char *connName);

#endif
