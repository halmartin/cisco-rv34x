#include "cp_main.h"
#include "cp_util.h"
void  cp_remove_lead_white_space(char *buf)
{
    int i=0;
    for(i=0;buf[i]==' ';i++);
    strcpy(buf,&buf[i]);
}

int
safe_open_rule_file (char *name)
{
    int fd;
    fd = open (name, O_RDWR | O_TRUNC | O_APPEND | O_CREAT, 0644);
    if (fd == -1)
    {
        CP_ERROR (1, "file '%s' opening failed", name);
        exit (1);
    }
    else
    {
        CP_ERROR (1, "file '%s' opening success", name);
        return fd;
    }

}

void *
safe_malloc (int size)
{
    void *ptr = NULL;
    if (size == 0)
    {
        CP_ERROR (1, "Zero size allocation no need %s", __func__);
        return NULL;
    }
    else
    {
        ptr = malloc (size);
        if (ptr == NULL)
        {
            exit (1);
        }
        else
        {
            safe_memset (ptr, 0, size);
        }
        return ptr;
    }
}

void *
safe_memset (void *data, int ch, int size)
{
    errno = 0;
    if (size == 0)
    {
        return NULL;
    }
    memset (data, ch, size);
    return data;
}

int
safe_memcpy (void *dest, void *src, int size)
{
    void *ptr = NULL;
    if (size == 0 || src == NULL)
    {
        return FAILURE;
    }
    ptr = safe_memset (dest, 0, size);
    if (ptr == NULL)
    {
        return FAILURE;
    }
    memcpy (ptr, src, size);
    return SUCCESS;
}

int
safe_memcmp (void *one, void *two, int size)
{
    if (one == NULL || two == NULL || size == 0)
    {

        CP_ERROR (1, "Memcmp input is wronge");
        exit (0);
    }
    return memcmp (one, two, size);
}

char *
mactoa (uint8_t * hw_addr)
{
    static char str[MAC_ADDR_STR_LEN + 1];
    snprintf (str, MAC_ADDR_STR_LEN + 1, "%02x:%02x:%02x:%02x:%02x:%02x",
            hw_addr[0], hw_addr[1], hw_addr[2],
            hw_addr[3], hw_addr[4], hw_addr[5]);
    return str;
}

int file_exist (char *filename)
{
    struct stat   buffer;   
    return (stat (filename, &buffer) == 0);
}

