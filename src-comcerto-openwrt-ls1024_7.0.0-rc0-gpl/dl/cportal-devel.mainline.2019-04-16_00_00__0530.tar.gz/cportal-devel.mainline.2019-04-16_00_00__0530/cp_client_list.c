#include "capportald.h"
#include "cp_client_list.h"
#include <inttypes.h>

static void client_timeout_handler(rm_client_by_action_t action, void *vap, void *ip_addr, uint8_t inactivity);
int client_index;
char buffer[STATUS_BUF_SIZE];
int len;

static struct bstree gClientByMacListHead[VAP_END];
static struct bstree gClientByIPListHead[VAP_END];
static client_node_t *node;
static const char *client_state_str[] =
{
    {"STATE START"},
    {"UNAUTHENTICATED"},
    {"AUTHENTICATING"},
    {"AUTHORIZED"},
    {"AUTHENTICATED"},
    {"LOGGED_OFF"},
    {"STATE END"},
};

void destroy_client_list_by_ip(rm_client_by_action_t action, int vap)
{
    struct bstree_node *first = bstree_first (&gClientByIPListHead[vap]);
#if 0
    if (first == NULL)
    {
        return;
    }
    client_node_t *p = bstree_container_of (first, client_node_t, node);
    if (p == NULL)
    {
        return;
    }
    cp_cancel_inactivity_timer((uint32_t)p->client.client_addr.ipv4.s_addr,vap);
    cp_cancel_session_timer((uint32_t)p->client.client_addr.ipv4.s_addr,vap);
    free (p);
#endif
    client_node_t *p = NULL;

    //    while (first = bstree_next (first) != NULL)
    while(1)
    {
        if (first == NULL)
        {
            return;
        }

        p = bstree_container_of (first, client_node_t, node);
        if (p == NULL)
        {
            break;
        }
#if 0
        cp_cancel_inactivity_timer((uint32_t)p->client.client_addr.ipv4.s_addr,vap);
        cp_cancel_session_timer((uint32_t)p->client.client_addr.ipv4.s_addr,vap);
        free (p);
#endif
        first = bstree_next (first);
        printf ("\n\nClient Ip Address         : \t%s\n",  inet_ntoa (p->client.client_addr.ipv4));
        client_timeout_handler(action,vap,p->client.client_addr.ipv4.s_addr,TRUE);

    }
}

void destroy_client_list_by_mac(rm_client_by_action_t action, int vap)
{
    struct bstree_node *first = bstree_first (&gClientByMacListHead[vap]);
#if 0
    if (first == NULL)
    {
        return;
    }
    client_node_t *p = bstree_container_of (first, client_node_t, node);
    if (p == NULL)
    {
        return;
    }
    //    cp_cancel_inactivity_timer((uint32_t)p->client.client_addr.ipv4.s_addr,vap);
    //    cp_cancel_session_timer((uint32_t)p->client.client_addr.ipv4.s_addr,vap);
    free (p);

    while (first = bstree_next (first) != NULL)
#endif
    client_node_t *p = NULL;
    while (1)
    {
        if (first == NULL)
        {
            return;
        }

        p = bstree_container_of (first, client_node_t, node);
        if (p == NULL)
        {
            break;
        }
        //	cp_cancel_inactivity_timer((uint32_t)p->client.client_addr.ipv4.s_addr,vap);
        //	cp_cancel_session_timer((uint32_t)p->client.client_addr.ipv4.s_addr,vap);
        //        free (p);
        first = bstree_next (first);
        printf ("\n\nClient Ip Address         : \t%s\n",  inet_ntoa (p->client.client_addr.ipv4));
        client_timeout_handler(action, vap,p->client.client_addr.ipv4.s_addr,TRUE);

    }
}

void destroy_client_list(rm_client_by_action_t action,int vap)
{
    destroy_client_list_by_mac(action,vap);
    destroy_client_list_by_ip(action,vap);
}

void deinit_client_list(rm_client_by_action_t action)
{
    int i;
    for (i=0;i < VAP_END ; i++) {
        if (cp_cfg[i].enabled == TRUE) {
            destroy_client_list(action,i);
        }
    }
}

void session_timeout_handler(void *vap, void *ip_addr)
{
    client_timeout_handler(IDLE_TIMEOUT,vap,ip_addr,FALSE);
    cp_cancel_inactivity_timer((uint32_t)ip_addr,(int)vap);
}

void inactivity_timeout_handler(void *vap_index, void *ip_address)
{
    int idle_time = 0;
    int vap = (int) vap_index ;
    uint32_t ip_addr = (uint32_t)ip_address;
    client_node_t *node = NULL;

    node = cp_client_present_ip_check(ip_addr, vap);
    if(node == NULL){
        CP_ERROR (1, "Client not present FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return;
    }

    idle_time = cp_client_idle_timeout_output(node);
    if ( (idle_time >= cp_cfg[vap].timeout) ) {
        client_timeout_handler(IDLE_TIMEOUT,vap_index,ip_address,TRUE);
        cp_cancel_session_timer(ip_addr,vap);
    } else if ( (idle_time == -1) ) {
        client_timeout_handler(WLAN_DISASSOC,vap_index,ip_address,TRUE);
        cp_cancel_session_timer(ip_addr,vap);
	/* Call timeout handler when expiration time is over for lobby user */
    } else if (node->client.cp_user == LOBBY_USR && time(NULL) >= node->client.lobby_time_exp) {
               cp_syslog(LOG_NOTICE,"Client(s) associated with lobby account is(are) disconnected \n");
                client_timeout_handler(IDLE_TIMEOUT,vap_index,ip_address,TRUE);
		cp_cancel_session_timer(ip_addr,vap);
    }else {
        cp_schedule_inactivity_timer(ip_addr, vap, cp_cfg[vap].timeout - idle_time);
    }
}

int cp_client_logoff_by_ip(void *ipv4_address)
{
    int i=0;
    uint32_t client_ipaddress = ((uint32_t)ipv4_address);
    struct client_node *node_ip = NULL;
    char *client_mac = NULL;
    char cmd_str[CMD_SIZE] = {'\0'};
    FILE *fp = NULL;

    for (i=0; i < VAP_END; i++) {
        node_ip = cp_client_present_ip_check(client_ipaddress,i);
	if (node_ip != NULL) {
            client_mac = node_ip->client.client_addr.mac;
            cp_client_state_change_without_search(node_ip,UNAUTHENTICATED);
            client_node_t *node_mac = NULL;
            node_mac = cp_client_present_check(client_mac,i);
            if(node_mac != NULL) {
		    /* Delete the cportal pid file if lobby user is terminated from UI */
		    sprintf(cmd_str,"find /tmp/cportal.* -type f -exec grep -H \'%x\'\{\} \\\; \| cut -d \: -f 1",client_ipaddress);
    if(fp = popen(cmd_str,"r"))  {
	    memset(cmd_str,0,CMD_SIZE);
	    if (fscanf(fp,"%s",cmd_str+6)){
		    fclose(fp);
		    strncpy(cmd_str,"rm -f ",6);
		    system(cmd_str);
		    /* Calling timeout handler and making timeout as 0 */
		    cp_cancel_inactivity_timer(client_ipaddress,i);
		    cp_schedule_inactivity_timer(client_ipaddress,i,0);
	    }
    }
 
                cp_flush_client_rules(i, mactoa(client_mac));
                cp_flush_client_route(i, mactoa(client_mac));
                cp_client_list_main (REMOVE, node_mac, i);
                free(node_mac);
                cp_syslog(LOG_NOTICE, "Client %s (%s) on SSID \"%s\" (%s) de-authenticated due to disconnect action applied by user",
                        inet_ntoa(node_ip->client.client_addr.ipv4), mactoa(client_mac), cp_cfg[i].wki.ssid,
                        gVapWlanMap[i]);
                return SUCCESS;
            }
            return FAILURE;
        }
    }
    return SUCCESS;
}

static void client_timeout_handler (rm_client_by_action_t action, void *vap, void *ip_addr, uint8_t inactivity)
{
    uint32_t client_ip = ((uint32_t)ip_addr);
    int client_vap = ((int) vap);
    struct client_node *node = NULL;
    char *client_mac= NULL;
    char cmd_str[CMD_SIZE] = {'\0'};
    FILE *fp =NULL;

    node = cp_client_present_ip_check(client_ip,client_vap);
    if(node == NULL){
        CP_ERROR (1, "Client not present FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        goto end;
    }
    client_mac = node->client.client_addr.mac;
    CP_ERROR(1,"Handling timeout handler for the mac %s %d",mactoa(client_mac),client_vap);
    if( (node->client.state.current == AUTHENTICATED) ) {
        if ( action  == DISCONNECT ) {
            cp_syslog(LOG_NOTICE, "Client %s (%s) on SSID \"%s\" (%s) de-authenticated due to disconnect action applied by user",
                    inet_ntoa(node->client.client_addr.ipv4), mactoa(client_mac), cp_cfg[client_vap].wki.ssid,
                    gVapWlanMap[client_vap]);
        } else if ( action  == SSID_CONF_CHANGE ) {
            cp_syslog(LOG_NOTICE, "Client %s (%s) on SSID \"%s\" (%s) de-authenticated due to this SSID profile changes",
                    inet_ntoa(node->client.client_addr.ipv4), mactoa(client_mac), cp_cfg[client_vap].wki.ssid,
                    gVapWlanMap[client_vap]);
        }else if ( action == IDLE_TIMEOUT ) {
            cp_syslog(LOG_NOTICE, "Client %s (%s) on SSID \"%s\" (%s) de-authenticated due to %s timer expiry",
                    inet_ntoa(node->client.client_addr.ipv4), mactoa(client_mac), cp_cfg[client_vap].wki.ssid,
                    gVapWlanMap[client_vap], inactivity ? "inactivity" : "session");
        } else if ( action == WLAN_DISASSOC ) {
            cp_syslog(LOG_NOTICE, "Client %s (%s) on SSID \"%s\" (%s) de-authenticated due to wireless client is disconnect from the AP",
                    inet_ntoa(node->client.client_addr.ipv4), mactoa(client_mac), cp_cfg[client_vap].wki.ssid,
                    gVapWlanMap[client_vap]);
        }
    }
    cp_client_state_change_without_search(node,UNAUTHENTICATED);

    client_node_t *node2 = NULL;
    node2 = cp_client_present_check(client_mac,client_vap);
    if(node2 != NULL) {
	    /* Delete the cportal pid file if lobby user is terminated after time expires */
    sprintf(cmd_str,"find /tmp/cportal.* -type f -exec grep -H \'%x\' \{\} \\\; \| cut -d \: -f 1",client_ip);
    if(fp = popen(cmd_str,"r")) {
	    memset(cmd_str,0,CMD_SIZE);
	    if (fscanf(fp,"%s",cmd_str+6)){
		    fclose(fp);
		    strncpy(cmd_str,"rm -f ",6);
		    system(cmd_str);
	    }
    }
 
        cp_flush_client_rules(client_vap, mactoa(client_mac));
        /*TODO the route file and rules will be cleared once user got apporved and
         * currently, we do not need to clear explicitly here */
        /* cp_flush_client_route(client_vap, mactoa(client_mac)); */
        cp_client_list_main (REMOVE, node2, client_vap);
        free(node2);
    }
end:
    return ;
}

void cp_cancel_inactivity_timer(uint32_t ip_addr,int vap)
{
    int ret=eloop_cancel_timeout ( inactivity_timeout_handler, (void *) vap, (void *)ip_addr);
    if(ret==0)
    {
        CP_ERROR(1,"timeout cancel failed");
        return;
    }
    CP_ERROR(1,"TImeout get canceled %d",ret);
}

void cp_cancel_session_timer(uint32_t ip_addr,int vap)
{
    int ret=eloop_cancel_timeout (session_timeout_handler, (void *) vap, (void *)ip_addr);
    if(ret==0)
    {
        CP_ERROR(1,"timeout cancel failed");
        return;
    }
    CP_ERROR(1,"TImeout get canceled %d",ret);
}

void cp_schedule_inactivity_timer (uint32_t ip_addr, int vap, int time)
{
    eloop_register_timeout (time, 0, inactivity_timeout_handler, (void *) vap, (void *)ip_addr);
}

void cp_schedule_session_timer(uint32_t ip_addr, int vap, int time)
{
    eloop_register_timeout (time, 0, session_timeout_handler, (void *) vap, (void *)ip_addr);
}

struct bstree_node *cp_lookup_node_from_tree (client_node_t * info, int vap)
{
    struct bstree_node *node;
    CP_ERROR (1, "Entered into the function %s", __func__);
    node = bstree_lookup (&(info->node), &gClientByMacListHead[vap]);
    if (node != NULL)
    {
        CP_ERROR (1,
                "Got the node from the lookup function FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return node;
    }
    CP_ERROR (1, "No node present in the function %s", __func__);
    return NULL;
}

struct bstree_node *cp_lookup_node_from_ip_tree (client_node_t * info, int vap)
{
    struct bstree_node *node;
    CP_ERROR (1, "Entered into the function %s", __func__);
    node = bstree_lookup (&(info->node), &gClientByIPListHead[vap]);
    if (node != NULL)
    {
        CP_ERROR (1,
                "Got the node from the lookup function FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return node;
    }
    CP_ERROR (1, "No node present in the function %s", __func__);
    return NULL;
}

int cp_get_client_present (nw_addr_t * client, int vap)
{
    client_node_t value;
    safe_memcpy (&value.client.client_addr, client, sizeof (nw_addr_t));
    struct bstree_node *node = cp_lookup_node_from_tree (&value, vap);
    if (node == NULL)
    {
        CP_ERROR (1,
                "Node is not present in the database FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return FAILURE;
    }
    else
    {
        return SUCCESS;
    }

}

client_node_t *cp_client_present_ip_check(uint32_t ip_addr , int vap)
{
    client_node_t *info = NULL;
    int ret;
    struct in_addr ipaddr;
    ipaddr.s_addr = ip_addr;
    ret = cp_get_client_node_ip_info (&info, &ipaddr, vap);
    if (ret == FAILURE)
    {
        CP_ERROR (1, "%s(): Node info fetch failed",
                __func__);
        return NULL;
    }
    return info;
}

void cp_client_state_change_without_search(client_node_t *info,int new_state)
{
    info->client.state.current = new_state;
    info->client.state.next = new_state + 1;
    switch (new_state)
    {
        case AUTHENTICATED:
            CP_INFO(1,"AUTHENTICATED CASE\n");
            info->client.session_time.start =  time(NULL);
            break;
        case UNAUTHENTICATED :
            CP_INFO(1,"UNAUTHENTICATED CASE\n");
            info->client.session_time.end  = time(NULL);
            break;
        default :
            return ;
    }
    return;
}

int cp_client_state_change_with_ip(uint32_t ip_addr,int new_state,int vap)
{
    client_node_t *info = NULL;
    int ret;
    struct in_addr ipaddr;
    ipaddr.s_addr = ip_addr;
    ret = cp_get_client_node_ip_info (&info, &ipaddr, vap);
    if (ret == FAILURE)
    {
        CP_ERROR (1, "%s(): Node info fetch failed",
                __func__);
        return FAILURE;
    }
    cp_client_state_change_without_search(info,new_state);
    return SUCCESS;
}

int cp_get_container_data (client_node_t ** value, struct bstree_node *node)
{


    *value = bstree_container_of (node, client_node_t, node);
    if (*value == NULL)
    {
        CP_ERROR (1, "Container function failed FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return FAILURE;
    }
    return SUCCESS;

}

int cp_get_client_node_info (client_node_t ** value, char *mac, int vap)
{
    struct bstree_node *node = NULL;
    client_node_t info;
    int vap_2=-1;
    int i;
    if (safe_memcpy (&info.client.client_addr.mac, mac, MAC_ADDR_LEN) == FAILURE)
    {
        CP_ERROR (1,
                "Memory copy failed in the function  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return FAILURE;
    }
    for (i=0;i< VAP_END ;i++) {
        if(i == vap)
            continue;
        node = cp_lookup_node_from_tree (&info, i);
        if(node != NULL) {
            vap_2 = i;
            break;
        }
    }

    if( (vap_2 != -1) )
    {
        CP_ERROR (1,"%s(%d) I will remove the old node!!!!!\n",__func__, __LINE__);
        cp_flush_client_rules(vap_2, mactoa(mac));
        cp_client_list_main (REMOVE, node, vap_2);
    }

    node = cp_lookup_node_from_tree (&info, vap);
    if (node == NULL)
    {
        CP_ERROR (1, "Node lookup failed FILE:%s-FUNCTION:%s-LINE:%d", __FILE__,
                __func__, __LINE__);
        return FAILURE;
    }
    int ret;
    ret = cp_get_container_data (value, node);
    if (ret == FAILURE)
    {
        CP_ERROR (1, "Container data failure FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return FAILURE;
    }

    return SUCCESS;
}

int cp_get_client_node_ip_info (client_node_t ** value, struct in_addr *ip, int vap)
{
    struct bstree_node *node = NULL;
    client_node_t info;
    if (safe_memcpy (&info.client.client_addr.ipv4, ip, sizeof(struct in_addr)) == FAILURE)
    {
        CP_ERROR (1,
                "Memory copy failed in the function  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return FAILURE;
    }

    node = cp_lookup_node_from_ip_tree (&info, vap);
    if (node == NULL)
    {
        CP_ERROR (1, "Node lookup failed FILE:%s-FUNCTION:%s-LINE:%d", __FILE__,
                __func__, __LINE__);
        return FAILURE;
    }

    int ret;
    ret = cp_get_container_data (value, node);
    if (ret == FAILURE)
    {
        CP_ERROR (1, "Container data failure FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return FAILURE;
    }

    return SUCCESS;
}

int cp_get_client_state_check (char *mac, int vap)
{
    client_node_t *info;
    int ret;
    ret = cp_get_client_node_info (&info, mac, vap);
    if (ret == FAILURE)
    {
        CP_ERROR (1, "Node info fetch failed FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return FAILURE;
    }
    else
    {
        CP_ERROR (1, "Node info fetch success FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
    }

    CP_ERROR(1,"Current state value is the %d",info->client.state.current);
    return info->client.state.current;

}

int cp_client_add_to_list (client_node_t *node, int vap)
{
    node->client.state.current=UNAUTHENTICATED;
    node->client.state.next=UNAUTHENTICATED;
    node->client.session_time.start=time(NULL);
    node->client.session_time.end=0;
    strcpy(node->client.vap_if_name,gVapWlanMap[vap]);
    cp_client_list_main (INSERT, node, vap);
    return SUCCESS;
}

client_node_t *cp_client_present_check (char *mac, int vap)
{
    client_node_t *info;
    int ret;
    ret = cp_get_client_node_info (&info, mac, vap);
    if (ret == FAILURE)
    {
        CP_ERROR (1, "Node info fetch failed FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return NULL;
    }
    else
    {
        CP_ERROR (1, "Node info fetch success FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return info;
    }
}

int cp_client_state_change (char *mac, int new_state, int vap)
{
    client_node_t *info;
    int ret;
    ret = cp_get_client_node_info (&info, mac, vap);
    if (ret == FAILURE)
    {
        CP_ERROR (1, "%s(): Node info fetch failed",
                __func__);
        return FAILURE;
    }
    else
    {
        CP_ERROR (1, "%s(): Node info fetch success (%s)",
                __func__, mactoa(info->client.client_addr.mac));
    }
    info->client.state.current = new_state;
    info->client.state.next = new_state + 1;
    switch (new_state)
    {
        case AUTHENTICATED:
            info->client.session_time.start =  time(NULL);
            break;
        case UNAUTHENTICATED :
            info->client.session_time.end  = time(NULL);
            break;
        default :
            return SUCCESS;
    }
}

static int cp_client_mac_cmp (struct bstree_node *one, struct bstree_node *two)
{
    if (one == NULL || two == NULL)
    {
        return 0;
    }
    client_node_t *p = bstree_container_of (one, client_node_t, node);
    client_node_t *q = bstree_container_of (two, client_node_t, node);
    if (p == NULL || q == NULL)
    {
        CP_ERROR (1,
                "Container node failed in cmp function FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return 0;
    }
    return memcmp ((void *)&p->client.client_addr.mac,
            (void *)&q->client.client_addr.mac, MAC_ADDR_LEN);
}

static int cp_client_ip_cmp (struct bstree_node *one, struct bstree_node *two)
{
    if (one == NULL || two == NULL)
    {
        return 0;
    }
    client_node_t *p = bstree_container_of (one, client_node_t, node);
    client_node_t *q = bstree_container_of (two, client_node_t, node);
    if (p == NULL || q == NULL)
    {
        CP_ERROR (1,
                "Container node failed in cmp function FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return 0;
    }
    return memcmp ((void *)&p->client.client_addr.ipv4,
            (void *)&q->client.client_addr.ipv4, sizeof(struct in_addr));
}

void _cp_client_list_init (int i)
{
    safe_memset (&gClientByMacListHead[i], 0, sizeof (struct bstree));
    safe_memset (&gClientByIPListHead[i], 0, sizeof (struct bstree));
    bstree_init (&gClientByMacListHead[i], (bstree_cmp_fn_t *) &cp_client_mac_cmp, 0);
    bstree_init (&gClientByIPListHead[i], (bstree_cmp_fn_t *) &cp_client_ip_cmp, 0);
}

/* Added by Yonghua, use fgets is very dangerous, we are not sure all uci settings are sequential */
int cp_init_profile(void)
{
    FILE *fd;
    int vap = 0;
    int ret;
    char temp[SIZE];
    char *ptr = NULL;
    char redir_url_tmp[SUCCESS_URL_LEN + 1];
    int redir_mask = 0;

    char str[512];
    int count = 0;
    int loop_i;

    fd = fopen(CP_PROFILE_FILE, "r");

    if (fd == NULL) {
        CP_ERROR(1, "fopen failed at FUNC:%s-LINE:%d\n", __func__, __LINE__);
        return -1;
    }

    while (fgets(temp, SIZE, fd) != NULL) {

        if (strstr(temp, "portal")) { /* get portal info */
            redir_mask = 0;
            for ( count = 0; ((count < 5) && (fgets(temp, SIZE, fd) != NULL)) ; count++) {
                if ( (ptr = strstr(temp, "profile")) ) {
                    vap = vap + 1;
                    sscanf(ptr+8,"'%[^']", cp_prof_cfg[vap - 1].profile_name);
                } else if ((ptr = strstr(temp, "captiveauth")) ) {
                    sscanf(ptr+12,"'%[^']", str);
                    cp_prof_cfg[vap - 1].cp_cfg.auth = atoi(str);
                } else if ((ptr = strstr(temp, "portal_redirect")) ) {
                    sscanf(ptr+16,"'%[^']", str);
                    loop_i = atoi(str);
                    if (loop_i) {
                        redir_mask = 1;
                    }
                } else if ( (ptr = strstr(temp, "portal_redirURL")) ) {
                    memset(redir_url_tmp,0,sizeof(redir_url_tmp));
                    sscanf(ptr+16,"'%[^']", redir_url_tmp);
                    if ( (NULL == strstr(redir_url_tmp,"http://"))&&
                            (NULL == strstr(redir_url_tmp,"https://")) ) {
                        sprintf(cp_prof_cfg[vap-1].cp_cfg.redir_url,"http://%s",redir_url_tmp);
                    } else {
                        strcpy(cp_prof_cfg[vap-1].cp_cfg.redir_url,redir_url_tmp);
                    }
                } else if ((ptr = strstr(temp, "timeout")) ) {
                    sscanf(ptr+8,"'%[^']", str);
                    cp_prof_cfg[vap-1].cp_cfg.timeout = atoi(str);
                }
            }

            if (redir_mask == 0) {
                cp_prof_cfg[vap-1].cp_cfg.redir_url[0] = 0x0;
            }
        }
    }
    fclose(fd);
    return SUCCESS;
}

int cp_client_list_init (void)
{
    int i = 0;
    for (i = 0; i < VAP_END; i++)
    {
        if ( (cp_cfg[i].ssid_enabled == 1) && (cp_cfg[i].enabled == TRUE) )
            _cp_client_list_init(i);
    }
    return SUCCESS;
}

static void cp_client_remove (client_node_t *node, int vap)
{
    client_node_t *node2 = NULL;
    int ret;

    ret = cp_get_client_node_ip_info(&node2, &node->client.client_addr.ipv4, vap);

    bstree_remove (node, &gClientByMacListHead[vap]);
    if ((ret != FAILURE) && (node2 != NULL)) {
        bstree_remove (node2, &gClientByIPListHead[vap]);
        free (node2);
    }
    return;
}

static void cp_client_insert_mac (client_node_t *node, int vap)
{
    CP_INFO (1, "%s: Adding client (%s) to MAC list", __func__, mactoa(node->client.client_addr.mac));
    bstree_insert (node, &gClientByMacListHead[vap]);
    return;
}

static void cp_client_insert_ip (client_node_t *node, int vap)
{
    CP_INFO (1, "%s: Adding client (%s) to IP list", __func__, inet_ntoa(node->client.client_addr.ipv4));
    bstree_insert (node, &gClientByIPListHead[vap]);
    return;
}

static void cp_client_insert (client_node_t *node, int vap)
{
    cp_client_insert_mac(node, vap);
    if (node->client.client_addr.ipv4.s_addr) {
        client_node_t *node2 = NULL;
        node2 = (client_node_t *) calloc(1, sizeof(client_node_t));
        if (node == NULL) {
            CP_ERROR (1, "Calloc Error %s:%d", __func__, __LINE__);
            return;
        }
        safe_memcpy (&node2->client, &node->client, sizeof(client_list_t));
        cp_client_insert_ip(node2, vap);
    }
    return;
}

static void cp_client_tx_and_rx_bytes (client_node_t *node)
{
    char tx_count[20]={0}, rx_count[20]={0}, tx_count_command[100]={0},rx_count_command[100]={0};
    FILE *fp;

    snprintf(tx_count_command,sizeof(tx_count_command),"wl -i %s sta_info %s \| grep \"tx total bytes\" \| awk \'{print $4}\'",node->client.vap_if_name,mactoa(node->client.client_addr.mac));

    fp = popen(tx_count_command,"r");

    if (fp == NULL) {
        CP_ERROR(1,"Failed to get tx count at FUNC:%s-LINE:%d \n", __func__, __LINE__);
        return;
    }

    if (fscanf(fp,"%s",tx_count)) {
        len += snprintf ((buffer + len), (sizeof(buffer) - len),"Number of Tx Bytes\t\t:\t%s\n",tx_count);
    }

    pclose(fp);

    snprintf(rx_count_command,sizeof(rx_count_command),"wl -i %s sta_info %s \| grep \"rx data bytes\" \| awk \'{print $4}\'",node->client.vap_if_name,mactoa(node->client.client_addr.mac));

    fp = popen(rx_count_command,"r");

    if (fp == NULL) {
        CP_ERROR(1,"Failed to get rx count at FUNC:%s-LINE:%d \n", __func__, __LINE__);
        return;
    }

    if (fscanf(fp, "%s", rx_count)) {
        len += snprintf ((buffer + len), (sizeof(buffer) - len),"Number of Rx Bytes\t\t:\t%s\n",rx_count);
    }

    pclose(fp);

    return;
}

static void cp_client_tx_and_rx_bytes_with_type(client_node_t *node)
{
    char tx_count[20]={0}, rx_count[20]={0}, tx_count_command[100]={0},rx_count_command[100]={0};
    FILE *fp;

    snprintf(tx_count_command,sizeof(tx_count_command),"wl -i %s sta_info %s \| grep \"tx total bytes\" \| awk \'{print $4}\'",node->client.vap_if_name,mactoa(node->client.client_addr.mac));

    fp = popen(tx_count_command,"r");

    if (fp == NULL) {
        CP_ERROR(1,"Failed to get tx count at FUNC:%s-LINE:%d \n", __func__, __LINE__);
        return;
    }

    if (fscanf(fp,"%s",tx_count)) {
        len += snprintf ((buffer + len), (sizeof(buffer) - len),"%s,",tx_count);
    }

    pclose(fp);

    snprintf(rx_count_command,sizeof(rx_count_command),"wl -i %s sta_info %s \| grep \"rx data bytes\" \| awk \'{print $4}\'",node->client.vap_if_name,mactoa(node->client.client_addr.mac));

    fp = popen(rx_count_command,"r");

    if (fp == NULL) {
        CP_ERROR(1,"Failed to get rx count at FUNC:%s-LINE:%d \n", __func__, __LINE__);
        return;
    }

    if (fscanf(fp, "%s", rx_count)) {
        len += snprintf ((buffer + len), (sizeof(buffer) - len),"%s,",rx_count);
    }

    pclose(fp);

    memset(tx_count_command, 0, 100);
    memset(rx_count_command, 0, 100);

    snprintf(tx_count_command,sizeof(tx_count_command),"wl -i %s sta_info %s \| grep \"tx total pkts\" \| awk \'{print $4}\'",node->client.vap_if_name,mactoa(node->client.client_addr.mac));

    fp = popen(tx_count_command,"r");

    if (fp == NULL) {
        CP_ERROR(1,"Failed to get tx pkts at FUNC:%s-LINE:%d \n", __func__, __LINE__);
        return;
    }

    if (fscanf(fp,"%s",tx_count)) {
        len += snprintf ((buffer + len), (sizeof(buffer) - len),"%s,",tx_count);
    }

    pclose(fp);

    snprintf(rx_count_command,sizeof(rx_count_command),"wl -i %s sta_info %s \| grep \"rx data pkts\" \| awk \'{print $4}\'",node->client.vap_if_name,mactoa(node->client.client_addr.mac));

    fp = popen(rx_count_command,"r");

    if (fp == NULL) {
        CP_ERROR(1,"Failed to get rx pkts at FUNC:%s-LINE:%d \n", __func__, __LINE__);
        return;
    }

    if (fscanf(fp, "%s", rx_count)) {
        len += snprintf ((buffer + len), (sizeof(buffer) - len),"%s,",rx_count);
    }

    pclose(fp);

    return;
}

void cp_client_print_data (client_node_t * p, int vap)
{
    switch(p->client.state.current) {
        case UNAUTHENTICATED:
            break;
        case AUTHENTICATED:
            len += snprintf((buffer + len),(sizeof(buffer) - len),"\n\nindex\t\t\t: %d\n",++client_index);
            len += snprintf((buffer + len), (sizeof(buffer) - len),"Current SSID    : \t%s\n",cp_cfg[vap].wki.ssid);
            len += snprintf((buffer + len), (sizeof(buffer) - len), "Username                         :\t%s\n",p->client.pam_data.username);
            len += snprintf ((buffer + len), (sizeof(buffer) - len),"Client Ip Address               : \t%s\n",
                    inet_ntoa (p->client.client_addr.ipv4));
            len += snprintf ((buffer + len), (sizeof(buffer) - len),"Client MAC Address              : \t%s\n",mactoa(p->client.client_addr.mac));
            len += snprintf ((buffer + len), (sizeof(buffer) - len),"Client Current State            : \t%s\n", client_state_str[p->client.state.current]);
            len += snprintf ((buffer + len), (sizeof(buffer) - len),"Client Session Connected time   : \t%d\n", (time(NULL)-p->client.session_time.start));
            len += snprintf ((buffer + len), (sizeof(buffer) - len),"Client interface Name           : \t%s\n", p->client.vap_if_name);
            cp_client_tx_and_rx_bytes(p);
            break;
        default:
            return;
    }

}

void cp_client_print_data_with_type(client_node_t * p, int vap, int status_type)
{
    switch(p->client.state.current) {
        case UNAUTHENTICATED:
            break;
        case AUTHENTICATED:
            if (status_type == STATUS_TYPE_SIMPLE) {
                len += snprintf ((buffer + len), (sizeof(buffer) - len),"%s,",
                        inet_ntoa (p->client.client_addr.ipv4));
                len += snprintf ((buffer + len), (sizeof(buffer) - len),"%s\n",mactoa(p->client.client_addr.mac));
            } else if (STATUS_TYPE_COMPLEX == status_type) {
                len += snprintf((buffer + len), (sizeof(buffer) - len), "%s,",p->client.pam_data.username);
                len += snprintf ((buffer + len), (sizeof(buffer) - len),"%s,",
                        inet_ntoa (p->client.client_addr.ipv4));
                len += snprintf ((buffer + len), (sizeof(buffer) - len),"%s,",mactoa(p->client.client_addr.mac));
                len += snprintf ((buffer + len), (sizeof(buffer) - len),"%s,", client_state_str[p->client.state.current]);
                len += snprintf ((buffer + len), (sizeof(buffer) - len),"%d,", (time(NULL)-p->client.session_time.start));
                len += snprintf ((buffer + len), (sizeof(buffer) - len),"%s,", p->client.vap_if_name);
                cp_client_tx_and_rx_bytes_with_type(p);
                if (is_lobby_user(p->client.pam_data.username) == TRUE) {
                    len += snprintf ((buffer + len), (sizeof(buffer) - len),"%d,", p->client.lobby_time_exp - time(NULL));
                } else {
                    len += snprintf ((buffer + len), (sizeof(buffer) - len),"%d,", cp_cfg[vap].timeout - (time(NULL) - p->client.session_time.start));
                }

                len += snprintf((buffer + len), (sizeof(buffer) - len),"SSID:%s\n",cp_cfg[vap].wki.ssid);
            }
            break;
        default:
            return;
    }

}
void update_allow_rule_client_list_by_ip(void)
{
    int lvap_index;
    struct bstree_node *first = NULL;
    client_node_t *p = NULL;

    for (lvap_index=0;lvap_index < VAP_END ; lvap_index++) {
        CP_INFO (1, "cp_cfg lvap=%d ssidenable=%d  enabled=%d\n", lvap_index, cp_cfg[lvap_index].ssid_enabled, cp_cfg[lvap_index].enabled);
        if ( (cp_cfg[lvap_index].ssid_enabled == 1) && (cp_cfg[lvap_index].enabled == TRUE) )
        {
            first = bstree_first (&gClientByIPListHead[lvap_index]);
            if (first == NULL)
            {
                continue;
            }
            p = bstree_container_of (first, client_node_t, node);
            if (p == NULL)
            {
                continue;
            }
            CP_INFO (1, "\n\nFirst Client Ip Address: \t%s  State_Current: %d \n",  inet_ntoa (p->client.client_addr.ipv4), p->client.state.current);
            if (AUTHENTICATED == p->client.state.current)
            {
                cp_update_client_rule(&(p->client.client_addr), lvap_index);
            }

            while (1)
            {
                first = bstree_next (first);
                p = bstree_container_of (first, client_node_t, node);
                if (p == NULL)
                {
                    break;
                }
                CP_INFO (1, "\n\nClient Ip Address: \t%s  State_Current: %d \n",  inet_ntoa (p->client.client_addr.ipv4), p->client.state.current);
                if (AUTHENTICATED == p->client.state.current)
                {
                    cp_update_client_rule(&(p->client.client_addr), lvap_index);
                }
            }
        }
    }
}

void cp_client_print (int vap)
{
    struct bstree_node *first = bstree_first (&gClientByIPListHead[vap]);
    if (first == NULL)
    {
        return;
    }
    client_node_t *p = bstree_container_of (first, client_node_t, node);
    if (p == NULL)
    {
        return;
    }
    cp_client_print_data (p, vap);

    while (1)
    {
        first = bstree_next (first);
        p = bstree_container_of (first, client_node_t, node);
        if (p == NULL)
        {
            break;
        }
        cp_client_print_data (p, vap);
    }
    client_index=0;
}

void cp_client_print_with_type(int vap, int status_type)
{
    struct bstree_node *first = bstree_first (&gClientByIPListHead[vap]);
    if (first == NULL)
    {
        return;
    }
    client_node_t *p = bstree_container_of (first, client_node_t, node);
    if (p == NULL)
    {
        return;
    }
    cp_client_print_data_with_type(p, vap, status_type);

    while (1)
    {
        first = bstree_next (first);
        p = bstree_container_of (first, client_node_t, node);
        if (p == NULL)
        {
            break;
        }
        cp_client_print_data_with_type(p, vap, status_type);
    }
    client_index=0;
}

void cp_client_print_all ()
{
    int i = 0, client_index = 0;
    len = 0;
    for (i = 0; i < VAP_END; i++)
    {
        if ( (cp_cfg[i].ssid_enabled == 1) && (cp_cfg[i].enabled == TRUE) )
            cp_client_print (i);
    }
}

void cp_client_print_all_with_type(int status_type)
{
    int i = 0, client_index = 0;
    len = 0;
    for (i = 0; i < VAP_END; i++)
    {
        if ( (cp_cfg[i].ssid_enabled == 1) && (cp_cfg[i].enabled == TRUE) )
            cp_client_print_with_type(i, status_type);
    }
}

void cp_client_list_main (bst_action_t action, client_node_t *node, int vap)
{
    int i = 0;
    switch (action)
    {

        case INSERT:
            cp_client_insert (node, vap);
            break;
        case INSERT_MAC:
            cp_client_insert_mac (node, vap);
            break;
        case INSERT_IP:
            cp_client_insert_ip (node, vap);
            break;
        case REMOVE:
            cp_client_remove (node, vap);
            break;
        case PRINT:
            cp_client_print_all ();
            break;
        default:
            CP_ERROR (1, "%s: Unknown Operation (%d)",
                    __func__, action);

    }

}

void cp_client_update_username(client_node_t *info,user_cred_t *pam_data)
{
    if (pam_data != NULL) {
        strncpy(info->client.pam_data.username, pam_data->username, USERNAME_SIZE);
    }
    return;
}
