#ifndef _CP_SOCKET_INIT_H
#define _CP_SOCKET_INIT_H 1

#include <netinet/in.h>
#include "cp_main.h"
#include <netinet/ip.h>
#include <fcntl.h>
typedef union
{
    struct sockaddr sa;
    struct sockaddr_in sa_in;
#ifdef IPV6_MGMT
    struct sockaddr_in6 sa_in6;
    struct sockaddr_storage sa_stor;
#endif				/* IPV6_MGMT */
} usockaddr;

typedef struct fds {
    int redir_http;
    int redir_https;
    int login_http;
    int login_https;
} fds_t;

#define SET_VAP_INSTANCE(i,s,r) (((i) & 0xFF) | (((s) & 0xFF) << 8) | (((r) & 0xFF) << 16))
#define GET_VAP_INSTANCE(x)     ((x) & 0xFF)
#define IS_INSTANCE_SSL(x)      !(!((x) & 0xFF00))
#define IS_INSTANCE_REDIR(x)    !(!((x) & 0xFF0000))

#define HTTP_PORT          80
#define HTTPS_PORT         443

#define CP_DNS_PORT     5001
#define CP_DNS_PORT_NO  53

#define LOGON_BASE_HTTP_PORT 8300
#define LOGON_BASE_HTTPS_PORT 9300

#define VAP_BASE_HTTP_NFQ_PORT 8100
#define VAP_BASE_HTTPS_NFQ_PORT 9100

#define VAP_BASE_LOGON_PORT_MARK 0x70

#define VAP_BASE_HTTP_PORT 0x40
#define VAP_BASE_HTTPS_PORT 0xc0

#define VAP_BASE_HTTP_NFQ_PORT_MARK 0xa0
#define VAP_BASE_HTTPS_NFQ_PORT_MARK 0x80

#define MAX_LISTEN 32

//extern int dman_cp_sock_fd;

void close_socket(int fd);
void close_registered_sockets(vap_if_index_t index);
int my_read(void *conn,int do_ssl, char *buffer, size_t len);
int ndelay_on (int fd);
int ndelay_off (int fd);

#endif
