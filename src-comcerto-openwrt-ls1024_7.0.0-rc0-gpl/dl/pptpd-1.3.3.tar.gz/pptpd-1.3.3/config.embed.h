/*
 * config.embed.h
 *
 * Dummy autoconf results for uClinux target.
 *
 * $Id: config.embed.h,v 1.4 2004/04/22 10:48:16 quozl Exp $
 */

#define STDC_HEADERS 1
#define HAVE_SETSID 1
#define HAVE_MEMMOVE 1
#define HAVE_STRING_H 1
#define PPP_BINARY "/bin/pppd"
#define BCRELAY_BIN "/bin/bcrelay"
#define SBINDIR "/bin"
